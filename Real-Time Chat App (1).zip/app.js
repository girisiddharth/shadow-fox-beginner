// --- DATA INITIALIZATION --- //
const basicOperations = [
  { name: 'Addition', symbol: '+' },
  { name: 'Subtraction', symbol: '-' },
  { name: 'Multiplication', symbol: '*' },
  { name: 'Division', symbol: '/' }
];
const scientificFunctions = [
  { name: 'Square Root', symbol: '√', operation: 'sqrt' },
  { name: 'Exponentiation', symbol: 'x^y', operation: 'pow' },
  { name: 'Square', symbol: 'x²', operation: 'square' },
  { name: 'Cube', symbol: 'x³', operation: 'cube' },
  { name: 'Sine', symbol: 'sin', operation: 'sin' },
  { name: 'Cosine', symbol: 'cos', operation: 'cos' },
  { name: 'Tangent', symbol: 'tan', operation: 'tan' },
  { name: 'Log10', symbol: 'log', operation: 'log10' },
  { name: 'Natural Log', symbol: 'ln', operation: 'ln' },
  { name: 'Factorial', symbol: 'n!', operation: 'factorial' },
  { name: 'Reciprocal', symbol: '1/x', operation: 'reciprocal' },
  { name: 'Percentage', symbol: '%', operation: 'percent' }
];
const constants = [
  { name: 'Pi', symbol: 'π', value: 3.14159265359 },
  { name: 'Euler', symbol: 'e', value: 2.71828182846 }
];
const unitTypes = {
  temperature: [
    { name: 'Celsius', code: 'C' },
    { name: 'Fahrenheit', code: 'F' },
    { name: 'Kelvin', code: 'K' }
  ],
  currency: [ 'USD', 'EUR', 'GBP', 'INR', 'JPY' ],
  length: [ 'meter', 'kilometer', 'centimeter', 'millimeter', 'mile', 'foot', 'inch' ],
  weight: [ 'kilogram', 'gram', 'pound', 'ounce' ],
  volume: [ 'liter', 'milliliter', 'gallon', 'cup' ]
};
const currencyRates = {
  USD: 1, EUR: 0.92, GBP: 0.79, INR: 83.5, JPY: 149.5
};
// --- STATE --- //
let currentTab = 'basic';
let basicState = { expr: '', result: '', history: [], error: null };
let sciState = {
  expr: '', result: '', history: [], error: null,
  memory: 0, memoryActive: false, degMode: true
};
let converterState = {
  type: 'temperature',
  fromUnit: 'C', toUnit: 'F', value: '', result: '', error: null
};
// --- UTILS --- //
function sanitizeInput(str) { return str.replace(/[^\d.()+\-*/^]/g, ''); }
function showError(msg, which = currentTab) {
  if (which === 'basic') {
    basicState.error = msg;
    showBasicDisplay();
  } else if (which === 'scientific') {
    sciState.error = msg;
    showScientificDisplay();
  } else if (which === 'converter') {
    converterState.error = msg;
    showConverter();
  }
  setTimeout(() => {
    if (which === 'basic') basicState.error = null;
    else if (which === 'scientific') sciState.error = null;
    else if (which === 'converter') converterState.error = null;
    refreshDisplays();
  }, 2400);
}
// --- TAB HANDLER --- //
document.querySelectorAll('.tab-btn').forEach(btn => {
  btn.addEventListener('click', e => {
    document.querySelectorAll('.tab-btn').forEach(tab => tab.classList.remove('active'));
    btn.classList.add('active');
    document.querySelectorAll('.calculator-view').forEach(view => view.classList.remove('active'));
    let tabid = btn.id.replace('tab-', '');
    document.getElementById('view-' + tabid).classList.add('active');
    currentTab = tabid;
    refreshDisplays();
  });
});
// --- BASIC BUTTONS --- //
function buildBasicButtons() {
  const grid = document.getElementById('basic-buttons');
  grid.innerHTML = '';
  const btns = [
    '7', '8', '9', '/',
    '4', '5', '6', '*',
    '1', '2', '3', '-',
    '0', '.', '+', '=',
    'C', 'DEL'
  ];
  btns.forEach(label => {
    const btn = document.createElement('button');
    btn.textContent = label;
    btn.className = 'btn ' +
      (/[0-9.]/.test(label) ? 'number-btn' :
      ['+', '-', '*', '/'].includes(label) ? 'operator-btn' :
      label === '=' ? 'equals-btn' :
      label === 'C' ? 'clear-btn' :
      label === 'DEL' ? 'delete-btn' : '');
    btn.setAttribute('data-value', label);
    btn.addEventListener('click', e => handleBasicClick(label));
    grid.appendChild(btn);
  });
}
function handleBasicClick(label) {
  if (label === 'C') {
    basicState.expr = '';
    basicState.result = '';
  } else if (label === 'DEL') {
    basicState.expr = basicState.expr.slice(0, -1);
  } else if (label === '=') {
    calculateBasic();
  } else {
    basicState.expr += label;
  }
  showBasicDisplay();
}
function calculateBasic() {
  try {
    let sanitized = basicState.expr.replace(/÷/g, '/').replace(/×/g, '*');
    if (/\/0(?!\d)/.test(sanitized)) throw Error('Division by zero');
    let res = Function('return ' + sanitized)();
    if (!isFinite(res)) throw Error('Invalid operation');
    basicState.result = parseFloat(res.toPrecision(12)).toString();
    saveBasicHistory(basicState.expr + ' = ' + basicState.result);
    basicState.expr = basicState.result;
  } catch (e) {
    showError(e.message, 'basic');
    basicState.result = '';
  }
}
function saveBasicHistory(record) {
  basicState.history.unshift(record);
  if (basicState.history.length > 5) basicState.history.pop();
  renderBasicHistory();
}
function renderBasicHistory() {
  const list = document.getElementById('basic-history-list');
  list.innerHTML = '';
  basicState.history.forEach(item => {
    const li = document.createElement('li');
    li.textContent = item;
    list.appendChild(li);
  });
}
function showBasicDisplay() {
  document.getElementById('basic-expression').textContent = basicState.expr;
  document.getElementById('basic-result').textContent = basicState.result;
  renderBasicHistory();
  if (basicState.error) {
    document.getElementById('basic-result').textContent = basicState.error;
    document.getElementById('basic-result').style.color = 'var(--color-error)';
  } else {
    document.getElementById('basic-result').style.color = 'var(--color-success)';
  }
}
// --- SCIENTIFIC BUTTONS --- //
function buildScientificButtons() {
  const grid = document.getElementById('sci-buttons');
  grid.innerHTML = '';
  const btnsRow1 = [ 'sin', 'cos', 'tan', 'deg/rad' ];
  const btnsRow2 = [ 'π', 'e', 'n!', '1/x' ];
  const btnsRow3 = [ 'log', 'ln', 'x²', 'x³' ];
  const btnsRow4 = [ '√', 'x^y', '%', 'C' ];
  const btnsRow5 = [ '7', '8', '9', '/' ];
  const btnsRow6 = [ '4', '5', '6', '*' ];
  const btnsRow7 = [ '1', '2', '3', '-' ];
  const btnsRow8 = [ '0', '.', '+', '=' ];
  const btnsRow9 = [ 'DEL', 'MR', 'MC', 'M+', 'M-' ];
  [btnsRow1, btnsRow2, btnsRow3, btnsRow4, btnsRow5, btnsRow6, btnsRow7, btnsRow8].forEach(row => {
    row.forEach(label => {
      const btn = document.createElement('button');
      btn.textContent = label;
      btn.className = 'btn ' +
        (/[0-9.]/.test(label) ? 'number-btn' :
        ['+', '-', '*', '/'].includes(label) ? 'operator-btn' :
        ['sin','cos','tan','x^y','√','x²','x³','log','ln','1/x', 'n!','π','e','%','deg/rad'].includes(label) ? 'sci-btn' :
        label === '=' ? 'equals-btn' :
        label === 'C' ? 'clear-btn' :
        label === 'DEL' ? 'delete-btn' :
        ['MR','MC','M+','M-'].includes(label) ? 'operator-btn' : '');
      btn.setAttribute('data-value', label);
      btn.addEventListener('click', e => handleScientificClick(label));
      grid.appendChild(btn);
    });
  });
  btnsRow9.forEach(label => {
    const btn = document.createElement('button');
    btn.textContent = label;
    btn.className = 'btn '+(['MR','MC','M+','M-'].includes(label)?'operator-btn':'');
    btn.setAttribute('data-value', label);
    btn.addEventListener('click', e => handleScientificClick(label));
    grid.appendChild(btn);
  });
}
function handleScientificClick(label) {
  if (label === 'C') {
    sciState.expr = '';
    sciState.result = '';
    sciState.error = null;
  } else if (label === 'DEL') {
    sciState.expr = sciState.expr.slice(0, -1);
  } else if (label === '=') {
    calculateScientific();
  } else if (label === 'π') {
    sciState.expr += constants[0].value;
  } else if (label === 'e') {
    sciState.expr += constants[1].value;
  } else if (['sin','cos','tan','log','ln','√','x²','x³','n!','1/x','%','x^y'].includes(label)) {
    sciState.expr += mapScientificOp(label);
  } else if (['MR','MC','M+','M-'].includes(label)) {
    handleMemory(label);
  } else if (label === 'deg/rad') {
    sciState.degMode = !sciState.degMode;
    updateDegRadBtn();
  } else {
    sciState.expr += label;
  }
  showScientificDisplay();
}
function mapScientificOp(label) {
  if (label === 'sin') return 'sin(';  if (label === 'cos') return 'cos(';  if (label === 'tan') return 'tan(';  if (label === 'log') return 'log(';  if (label === 'ln') return 'ln(';  if (label === '√') return 'sqrt(';  if (label === 'x²') return '^2';  if (label === 'x³') return '^3';  if (label === 'n!') return '!';  if (label === '1/x') return '1/';  if (label === '%') return '/100';  if (label === 'x^y') return '^';
  return '';
}
function calculateScientific() {
  try {
    let expr = sciState.expr;
    let parsed = expr
      .replace(/sin\(/g, 'Math.sin(')
      .replace(/cos\(/g, 'Math.cos(')
      .replace(/tan\(/g, 'Math.tan(')
      .replace(/log\(/g, 'Math.log10(')
      .replace(/ln\(/g, 'Math.log(')
      .replace(/sqrt\(/g, 'Math.sqrt(')
      .replace(/([\d.]+)!/g, (_,n) => 'factorial('+n+')')
      .replace(/([\d.]+)\^([\d.]+)/g, (_,b,e) => 'Math.pow('+b+','+e+')');
    if (sciState.degMode) {
      parsed = parsed.replace(/Math\.(sin|cos|tan)\(([^)]+)\)/g, (m,fn,arg) => {
        return `Math.${fn}((${arg})*Math.PI/180)`; // convert to rad
      });
    }
    let safeEval = new Function('factorial',parsed => {
      function factorial(n) { if (n < 0 || n !== Math.floor(n)) throw Error('Invalid factorial'); return n <= 1 ? 1 : n*factorial(n-1); }
      return eval(parsed);
    });
    let res = safeEval(function factorial(n){ if(n < 0||n!==Math.floor(n)) throw Error('Invalid factorial'); return n<=1?1:n*factorial(n-1); }, parsed);
    if (!isFinite(res)) throw Error('Invalid operation');
    sciState.result = parseFloat(res.toPrecision(12)).toString();
    saveSciHistory(sciState.expr + ' = ' + sciState.result);
    sciState.expr = sciState.result;
  } catch (e) {
    showError(e.message, 'scientific');
    sciState.result = '';
  }
}
function saveSciHistory(record) {
  sciState.history.unshift(record);
  if (sciState.history.length > 5) sciState.history.pop();
  renderSciHistory();
}
function renderSciHistory() {
  const list = document.getElementById('sci-history-list');
  list.innerHTML = '';
  sciState.history.forEach(item => {
    const li = document.createElement('li');
    li.textContent = item;
    list.appendChild(li);
  });
}
function showScientificDisplay() {
  document.getElementById('sci-expression').textContent = sciState.expr;
  document.getElementById('sci-result').textContent = sciState.result;
  renderSciHistory();
  updateMemoryIndicator();
  updateDegRadBtn();
  if (sciState.error) {
    document.getElementById('sci-result').textContent = sciState.error;
    document.getElementById('sci-result').style.color = 'var(--color-error)';
  } else {
    document.getElementById('sci-result').style.color = 'var(--color-success)';
  }
}
function updateDegRadBtn() {
  document.getElementById('deg-rad-toggle').textContent = (sciState.degMode ? 'Deg' : 'Rad');
}
function updateMemoryIndicator() {
  document.getElementById('memory-indicator').textContent = (sciState.memory !== 0 ? 'M' : '');
}
function handleMemory(label) {
  let val = sciState.result ? Number(sciState.result) : 0;
  if (label === 'M+') sciState.memory += val;
  if (label === 'M-') sciState.memory -= val;
  if (label === 'MR') {
    sciState.expr = sciState.memory.toString();
  }
  if (label === 'MC') sciState.memory = 0;
  sciState.memoryActive = (sciState.memory !== 0);
  updateMemoryIndicator();
}
// --- CONVERTER --- //
function buildConverterTabs() {
  document.querySelectorAll('.converter-tab').forEach((tab, idx) => {
    tab.addEventListener('click', () => {
      document.querySelectorAll('.converter-tab').forEach(tab2 => tab2.classList.remove('active'));
      tab.classList.add('active');
      converterState.type = tab.dataset.type;
      buildConverterUi(converterState.type);
    });
  });
}
function buildConverterUi(type) {
  const area = document.getElementById('converter-area');
  area.innerHTML = '';
  if (type === 'temperature') {
    area.appendChild(temperatureConverter());
  } else if (type === 'currency') {
    area.appendChild(currencyConverter());
  } else if (type === 'length') {
    area.appendChild(unitConverterRow('Length', unitTypes.length));
  } else if (type === 'weight') {
    area.appendChild(unitConverterRow('Weight', unitTypes.weight));
  } else if (type === 'volume') {
    area.appendChild(unitConverterRow('Volume', unitTypes.volume));
  }
}
function temperatureConverter() {
  const root = document.createElement('div');
  root.className = 'converter-row';
  // Input
  root.innerHTML = `
    <label class="converter-label">Value:</label>
    <input type="number" class="converter-input" id="temp-input" placeholder="Enter value" value="" />
    <select id="temp-from" class="converter-select">
      <option value="C">Celsius (°C)</option>
      <option value="F">Fahrenheit (°F)</option>
      <option value="K">Kelvin (K)</option>
    </select>
    <button class="btn converter-clear-btn" id="temp-clear">Clear</button>
  `;
  const resultDiv = document.createElement('div');
  resultDiv.className = 'converter-result';
  resultDiv.id = 'temp-results';
  root.appendChild(resultDiv);
  root.querySelector('#temp-input').addEventListener('input', tempConvertHandler);
  root.querySelector('#temp-from').addEventListener('change', tempConvertHandler);
  root.querySelector('#temp-clear').addEventListener('click', () => {
    root.querySelector('#temp-input').value = '';
    resultDiv.innerHTML = '';
  });
  return root;
}
function tempConvertHandler() {
  let val = Number(document.getElementById('temp-input').value);
  let from = document.getElementById('temp-from').value;
  if (isNaN(val)) return;
  let C = (from === 'C') ? val : (from === 'F') ? (val - 32) * 5/9 : (val - 273.15);
  let F = (C * 9/5) + 32;
  let K = C + 273.15;
  document.getElementById('temp-results').innerHTML =
    `<b>Celsius:</b> ${C.toFixed(2)} °C<br>
     <b>Fahrenheit:</b> ${F.toFixed(2)} °F<br>
     <b>Kelvin:</b> ${K.toFixed(2)} K`;
}
function currencyConverter() {
  const root = document.createElement('div');
  root.className = 'converter-row';
  root.innerHTML = `
    <label class="converter-label">Amount:</label>
    <input type="number" class="converter-input" id="curr-input" placeholder="Enter amount" value="" min="0" />
    <select id="curr-from" class="converter-select">
      ${unitTypes.currency.map(c=>`<option value="${c}">${c}</option>`).join('')}
    </select>
    <select id="curr-to" class="converter-select">
      ${unitTypes.currency.map(c=>`<option value="${c}">${c}</option>`).join('')}
    </select>
    <button class="btn converter-clear-btn" id="curr-clear">Clear</button>
  `;
  const resultDiv = document.createElement('div');
  resultDiv.className = 'converter-result';
  resultDiv.id = 'curr-results';
  root.appendChild(resultDiv);
  root.querySelector('#curr-input').addEventListener('input', currencyConvertHandler);
  root.querySelector('#curr-from').addEventListener('change', currencyConvertHandler);
  root.querySelector('#curr-to').addEventListener('change', currencyConvertHandler);
  root.querySelector('#curr-clear').addEventListener('click', () => {
    root.querySelector('#curr-input').value = '';
    resultDiv.innerHTML = '';
  });
  return root;
}
function currencyConvertHandler() {
  let val = Number(document.getElementById('curr-input').value);
  let from = document.getElementById('curr-from').value;
  let to = document.getElementById('curr-to').value;
  if (isNaN(val)) return;
  let usdAmount = val / currencyRates[from];
  let out = usdAmount * currencyRates[to];
  document.getElementById('curr-results').innerHTML =
    `<b>${val.toFixed(2)} ${from}</b> ≈ <b>${out.toFixed(2)} ${to}</b><br>(Rates: demo as of Nov 2025)`;
}
function unitConverterRow(type, units) {
  const root = document.createElement('div');
  root.className = 'converter-row';
  root.innerHTML = `
    <label class="converter-label">Value:</label>
    <input type="number" class="converter-input" id="uc-input" placeholder="Enter value" value="" />
    <select id="uc-from" class="converter-select">
      ${units.map(u=>`<option value="${u}">${u[0].toUpperCase()+u.slice(1)}</option>`).join('')}
    </select>
    <select id="uc-to" class="converter-select">
      ${units.map(u=>`<option value="${u}">${u[0].toUpperCase()+u.slice(1)}</option>`).join('')}
    </select>
    <button class="btn converter-clear-btn" id="uc-clear">Clear</button>
  `;
  const resultDiv = document.createElement('div');
  resultDiv.className = 'converter-result';
  resultDiv.id = 'uc-results';
  root.appendChild(resultDiv);
  root.querySelector('#uc-input').addEventListener('input', () => unitConvertHandler(type.toLowerCase()));
  root.querySelector('#uc-from').addEventListener('change', () => unitConvertHandler(type.toLowerCase()));
  root.querySelector('#uc-to').addEventListener('change', () => unitConvertHandler(type.toLowerCase()));
  root.querySelector('#uc-clear').addEventListener('click', () => {
    root.querySelector('#uc-input').value = '';
    resultDiv.innerHTML = '';
  });
  return root;
}
function unitConvertHandler(type) {
  let val = Number(document.getElementById('uc-input').value);
  let from = document.getElementById('uc-from').value;
  let to = document.getElementById('uc-to').value;
  if (isNaN(val)) return;
  let factor = 1, out = val;
  if (type === 'length') {
    const table = {
      meter: 1,
      kilometer: 1000,
      centimeter: 0.01,
      millimeter: 0.001,
      mile: 1609.34,
      foot: 0.3048,
      inch: 0.0254
    };
    out = val * table[from] / table[to];
  } else if (type === 'weight') {
    const table = {
      kilogram: 1,
      gram: 0.001,
      pound: 0.453592,
      ounce: 0.0283495
    };
    out = val * table[from] / table[to];
  } else if (type === 'volume') {
    const table = {
      liter: 1,
      milliliter: 0.001,
      gallon: 3.78541,
      cup: 0.236588
    };
    out = val * table[from] / table[to];
  }
  document.getElementById('uc-results').innerHTML = `<b>${val} ${from}</b> ≈ <b>${out.toFixed(4)} ${to}</b>`;
}
// --- KEYBOARD SUPPORT --- //
document.addEventListener('keydown', e => {
  let key = e.key;
  if (currentTab === 'basic') {
    if (/^[0-9]$/.test(key) || key === '.') basicState.expr += key;
    else if (['+', '-', '*', '/'].includes(key)) basicState.expr += key;
    else if (key === 'Enter') calculateBasic();
    else if (key === 'Backspace') basicState.expr = basicState.expr.slice(0,-1);
    else if (key === 'Escape') { basicState.expr = ''; basicState.result = ''; }
    showBasicDisplay();
  } else if (currentTab === 'scientific') {
    if (/^[0-9]$/.test(key) || key === '.') sciState.expr += key;
    else if (['+', '-', '*', '/'].includes(key)) sciState.expr += key;
    else if (key === 'Enter') calculateScientific();
    else if (key === 'Backspace') sciState.expr = sciState.expr.slice(0,-1);
    else if (key === 'Escape') { sciState.expr = ''; sciState.result = ''; }
    showScientificDisplay();
  }
});
// --- INITIALIZE --- //
function refreshDisplays() {
  showBasicDisplay();
  showScientificDisplay();
  showConverter();
}
function showConverter() {
  buildConverterUi(converterState.type);
}
document.addEventListener('DOMContentLoaded', () => {
  buildBasicButtons();
  buildScientificButtons();
  renderBasicHistory();
  renderSciHistory();
  showBasicDisplay();
  showScientificDisplay();
  buildConverterTabs();
  buildConverterUi('temperature');
});
