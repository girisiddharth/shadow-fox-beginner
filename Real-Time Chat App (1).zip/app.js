// ========== DATA STRUCTURES ==========

const ROOMS = [
  {
    id: 'room_1',
    name: 'General',
    description: 'General discussion for everyone',
    icon: '💬',
    users: [],
    messages: [],
    unreadCount: 0
  },
  {
    id: 'room_2',
    name: 'Tech Discussion',
    description: 'Discuss technology, programming, and web dev',
    icon: '💻',
    users: [],
    messages: [],
    unreadCount: 0
  },
  {
    id: 'room_3',
    name: 'Gaming',
    description: 'Gaming, esports, and game development',
    icon: '🎮',
    users: [],
    messages: [],
    unreadCount: 0
  },
  {
    id: 'room_4',
    name: 'Random',
    description: 'Off-topic conversations and memes',
    icon: '🎲',
    users: [],
    messages: [],
    unreadCount: 0
  },
  {
    id: 'room_5',
    name: 'Study Group',
    description: 'Collaborative learning and homework help',
    icon: '📚',
    users: [],
    messages: [],
    unreadCount: 0
  }
];

const USER_COLORS = [
  '#FF6B6B', '#4ECDC4', '#45B7D1', '#FFA07A',
  '#98D8C8', '#F7DC6F', '#BB8FCE', '#85C1E2'
];

// Simulated other users for demo
const SIMULATED_USERS = [
  { username: 'Alice', id: 'user_sim_1' },
  { username: 'Bob', id: 'user_sim_2' },
  { username: 'Charlie', id: 'user_sim_3' },
  { username: 'Diana', id: 'user_sim_4' }
];

// ========== STATE ==========

let currentUser = null;
let currentRoom = ROOMS[0];
let allUsers = {}; // username -> user object
let connectionStatus = 'connected';
let typingUsers = new Set();
let typingTimeout = null;
let messageIdCounter = 1;

// Settings
let settings = {
  notifications: false,
  sound: false,
  autoScroll: true
};

// ========== UTILITY FUNCTIONS ==========

function generateId() {
  return 'msg_' + Date.now() + '_' + Math.random().toString(36).substr(2, 9);
}

function generateUserId() {
  return 'user_' + Date.now() + '_' + Math.random().toString(36).substr(2, 9);
}

function getRandomColor() {
  return USER_COLORS[Math.floor(Math.random() * USER_COLORS.length)];
}

function formatTime(date) {
  const hours = date.getHours().toString().padStart(2, '0');
  const minutes = date.getMinutes().toString().padStart(2, '0');
  const seconds = date.getSeconds().toString().padStart(2, '0');
  return `${hours}:${minutes}:${seconds}`;
}

function sanitizeUsername(username) {
  return username.replace(/[^a-zA-Z0-9_-]/g, '').slice(0, 20);
}

function detectLinks(text) {
  const urlRegex = /(https?:\/\/[^\s]+)/g;
  return text.replace(urlRegex, (url) => {
    return `<a href="${url}" target="_blank" rel="noopener noreferrer">${url}</a>`;
  });
}

function formatMessage(text) {
  // Handle code blocks
  text = text.replace(/```([^`]+)```/g, '<code>$1</code>');
  // Detect links
  text = detectLinks(text);
  // Escape HTML
  const div = document.createElement('div');
  div.textContent = text;
  let escaped = div.innerHTML;
  // Re-apply formatting
  escaped = escaped.replace(/```([^`]+)```/g, '<code>$1</code>');
  escaped = detectLinks(escaped);
  return escaped;
}

function showToast(message, duration = 3000) {
  const toast = document.getElementById('toast');
  toast.textContent = message;
  toast.classList.add('show');
  setTimeout(() => {
    toast.classList.remove('show');
  }, duration);
}

function escapeHtml(text) {
  const div = document.createElement('div');
  div.textContent = text;
  return div.innerHTML;
}

// ========== LOGIN LOGIC ==========

function validateUsername(username) {
  if (username.length < 3 || username.length > 20) {
    return 'Username must be 3-20 characters';
  }
  if (!/^[a-zA-Z0-9_-]+$/.test(username)) {
    return 'Username can only contain letters, numbers, _ and -';
  }
  if (allUsers[username]) {
    return 'Username already taken';
  }
  return null;
}

function handleLogin(e) {
  e.preventDefault();
  const usernameInput = document.getElementById('username');
  const username = sanitizeUsername(usernameInput.value.trim());
  const errorDiv = document.getElementById('username-error');

  const error = validateUsername(username);
  if (error) {
    errorDiv.textContent = error;
    errorDiv.classList.add('show');
    return;
  }

  // Create user
  currentUser = {
    id: generateUserId(),
    username: username,
    color: getRandomColor(),
    status: 'online',
    joinedAt: new Date()
  };

  allUsers[username] = currentUser;

  // Add user to current room
  currentRoom.users.push(currentUser);

  // Add simulated users
  SIMULATED_USERS.forEach(sim => {
    if (!allUsers[sim.username]) {
      const simUser = {
        id: sim.id,
        username: sim.username,
        color: getRandomColor(),
        status: 'online',
        joinedAt: new Date()
      };
      allUsers[sim.username] = simUser;
      currentRoom.users.push(simUser);
    }
  });

  // Add join message
  addSystemMessage(`${username} joined the chat`, currentRoom);

  // Show chat app
  document.getElementById('login-screen').style.display = 'none';
  document.getElementById('chat-app').classList.add('active');

  // Initialize UI
  initializeChatApp();
  
  // Simulate network activity
  simulateNetworkActivity();
}

function initializeChatApp() {
  renderRoomsList();
  renderUsersList();
  renderMessages();
  updateChatHeader();
  updateUserInfo();
  
  // Add welcome message
  setTimeout(() => {
    addSystemMessage('Welcome to the chat! Start a conversation.', currentRoom);
    renderMessages();
  }, 500);
}

// ========== MESSAGE LOGIC ==========

function createMessage(text, user, room, type = 'message') {
  return {
    id: generateId(),
    username: user.username,
    userId: user.id,
    text: text,
    timestamp: new Date().toISOString(),
    roomId: room.id,
    type: type,
    edited: false,
    editedAt: null,
    color: user.color,
    delivered: false
  };
}

function addSystemMessage(text, room) {
  const msg = {
    id: generateId(),
    text: text,
    timestamp: new Date().toISOString(),
    roomId: room.id,
    type: 'system'
  };
  room.messages.push(msg);
  return msg;
}

function sendMessage() {
  const input = document.getElementById('message-input');
  const text = input.value.trim();

  if (!text || text.length > 500) return;

  // Create and add message
  const message = createMessage(text, currentUser, currentRoom);
  currentRoom.messages.push(message);
  
  // Clear input
  input.value = '';
  updateCharCount();
  
  // Render
  renderMessages();
  
  // Simulate network delay for delivery
  setTimeout(() => {
    message.delivered = true;
    renderMessages();
  }, Math.random() * 200 + 100);
  
  // Stop typing indicator
  stopTyping();
  
  // Simulate responses
  simulateResponse();
}

function simulateResponse() {
  // Random chance of getting a response
  if (Math.random() > 0.3) return;
  
  const responses = [
    'That\'s interesting!',
    'I agree with that',
    'Thanks for sharing',
    'Good point',
    'Nice! 👍',
    'What do you think about that?',
    'I was just thinking the same thing',
    'Can you elaborate?',
    'That makes sense'
  ];
  
  const randomUser = SIMULATED_USERS[Math.floor(Math.random() * SIMULATED_USERS.length)];
  const user = allUsers[randomUser.username];
  
  if (!user) return;
  
  // Show typing
  typingUsers.add(user.username);
  renderTypingIndicator();
  
  setTimeout(() => {
    typingUsers.delete(user.username);
    renderTypingIndicator();
    
    const response = responses[Math.floor(Math.random() * responses.length)];
    const message = createMessage(response, user, currentRoom);
    currentRoom.messages.push(message);
    
    // Mark as unread if not in current room
    if (currentRoom.id !== message.roomId) {
      const room = ROOMS.find(r => r.id === message.roomId);
      if (room) room.unreadCount++;
      renderRoomsList();
    }
    
    renderMessages();
    
    setTimeout(() => {
      message.delivered = true;
      renderMessages();
    }, 100);
  }, Math.random() * 2000 + 1000);
}

function deleteMessage(messageId) {
  const message = currentRoom.messages.find(m => m.id === messageId);
  if (!message || message.userId !== currentUser.id) return;
  
  message.text = '[Message deleted]';
  message.deleted = true;
  renderMessages();
  showToast('Message deleted');
}

function replyToMessage(messageId) {
  const message = currentRoom.messages.find(m => m.id === messageId);
  if (!message) return;
  
  const input = document.getElementById('message-input');
  input.value = `@${message.username} `;
  input.focus();
}

// ========== TYPING INDICATOR ==========

function handleTyping() {
  if (typingTimeout) clearTimeout(typingTimeout);
  
  // Simulate sending typing status
  if (!typingUsers.has(currentUser.username)) {
    // Broadcast typing
  }
  
  typingTimeout = setTimeout(() => {
    stopTyping();
  }, 2000);
}

function stopTyping() {
  if (typingTimeout) clearTimeout(typingTimeout);
  typingUsers.delete(currentUser.username);
}

function renderTypingIndicator() {
  const indicator = document.getElementById('typing-indicator');
  const typingArray = Array.from(typingUsers).filter(u => u !== currentUser.username);
  
  if (typingArray.length === 0) {
    indicator.style.display = 'none';
    return;
  }
  
  indicator.style.display = 'block';
  const names = typingArray.join(', ');
  const verb = typingArray.length === 1 ? 'is' : 'are';
  indicator.innerHTML = `${names} ${verb} typing<span class="typing-dots"><span></span><span></span><span></span></span>`;
}

// ========== RENDER FUNCTIONS ==========

function renderRoomsList() {
  const list = document.getElementById('rooms-list');
  list.innerHTML = '';
  
  ROOMS.forEach(room => {
    const item = document.createElement('div');
    item.className = 'room-item' + (room.id === currentRoom.id ? ' active' : '');
    
    const userCount = room.users.length;
    
    item.innerHTML = `
      <span class="room-icon">${room.icon}</span>
      <div class="room-info">
        <div class="room-name">${escapeHtml(room.name)}</div>
        <div class="room-users">${userCount} user${userCount !== 1 ? 's' : ''}</div>
      </div>
      ${room.unreadCount > 0 ? `<span class="unread-badge">${room.unreadCount}</span>` : ''}
    `;
    
    item.onclick = () => switchRoom(room);
    list.appendChild(item);
  });
}

function renderUsersList() {
  const list = document.getElementById('users-list');
  const count = document.getElementById('users-count');
  
  const users = currentRoom.users;
  count.textContent = `${users.length} user${users.length !== 1 ? 's' : ''}`;
  
  list.innerHTML = '';
  users.forEach(user => {
    const item = document.createElement('div');
    item.className = 'user-item';
    
    const isTyping = typingUsers.has(user.username);
    const statusClass = isTyping ? 'typing' : 'online';
    
    item.innerHTML = `
      <span class="user-status ${statusClass}"></span>
      <span class="user-name" style="color: ${user.color}">${escapeHtml(user.username)}</span>
    `;
    
    list.appendChild(item);
  });
}

function renderMessages() {
  const container = document.getElementById('messages-container');
  const shouldScroll = settings.autoScroll && 
    (container.scrollHeight - container.scrollTop - container.clientHeight < 100);
  
  container.innerHTML = '';
  
  currentRoom.messages.forEach(message => {
    const messageEl = document.createElement('div');
    messageEl.className = 'message' + (message.type === 'system' ? ' system' : '');
    
    if (message.type === 'system') {
      messageEl.textContent = message.text;
    } else {
      const time = formatTime(new Date(message.timestamp));
      const initials = message.username.substring(0, 2).toUpperCase();
      const isOwn = message.userId === currentUser.id;
      const canDelete = isOwn && !message.deleted;
      
      messageEl.innerHTML = `
        <div class="message-avatar" style="background-color: ${message.color}">${initials}</div>
        <div class="message-content">
          <div class="message-header">
            <span class="message-username" style="color: ${message.color}">${escapeHtml(message.username)}</span>
            <span class="message-time">${time}</span>
            ${message.delivered ? '<span style="color: var(--color-success); font-size: 10px;">✓</span>' : ''}
            ${message.edited ? '<span class="message-edited">(edited)</span>' : ''}
          </div>
          <div class="message-text ${message.deleted ? 'deleted' : ''}">${message.deleted ? message.text : formatMessage(message.text)}</div>
          ${!message.deleted ? `
            <div class="message-actions">
              <button class="message-action-btn" onclick="replyToMessage('${message.id}')">Reply</button>
              ${canDelete ? `<button class="message-action-btn" onclick="deleteMessage('${message.id}')">Delete</button>` : ''}
            </div>
          ` : ''}
        </div>
      `;
    }
    
    container.appendChild(messageEl);
  });
  
  if (shouldScroll) {
    container.scrollTop = container.scrollHeight;
  }
}

function updateChatHeader() {
  document.getElementById('current-room-name').textContent = currentRoom.name;
  document.getElementById('current-room-desc').textContent = currentRoom.description;
}

function updateUserInfo() {
  const info = document.getElementById('user-info');
  info.textContent = `Logged in as ${currentUser.username}`;
}

function updateCharCount() {
  const input = document.getElementById('message-input');
  const counter = document.getElementById('char-count');
  const length = input.value.length;
  
  counter.textContent = `${length}/500`;
  counter.className = 'char-count';
  
  if (length > 450) {
    counter.classList.add('warning');
  }
  if (length >= 500) {
    counter.classList.add('error');
  }
}

// ========== ROOM MANAGEMENT ==========

function switchRoom(room) {
  if (room.id === currentRoom.id) return;
  
  // Leave current room
  const userIndex = currentRoom.users.findIndex(u => u.id === currentUser.id);
  if (userIndex !== -1) {
    currentRoom.users.splice(userIndex, 1);
  }
  
  // Join new room
  currentRoom = room;
  room.unreadCount = 0;
  
  if (!room.users.find(u => u.id === currentUser.id)) {
    room.users.push(currentUser);
    // Add simulated users to new room
    SIMULATED_USERS.forEach(sim => {
      const user = allUsers[sim.username];
      if (user && !room.users.find(u => u.id === user.id)) {
        room.users.push(user);
      }
    });
    addSystemMessage(`${currentUser.username} joined the room`, room);
  }
  
  renderRoomsList();
  renderUsersList();
  renderMessages();
  updateChatHeader();
  
  showToast(`Switched to ${room.name}`);
}

function createNewRoom() {
  const nameInput = document.getElementById('new-room-name');
  const descInput = document.getElementById('new-room-desc');
  
  const name = nameInput.value.trim();
  const description = descInput.value.trim();
  
  if (!name) {
    showToast('Please enter a room name');
    return;
  }
  
  const newRoom = {
    id: 'room_' + Date.now(),
    name: name,
    description: description || 'Custom room',
    icon: '🆕',
    users: [currentUser],
    messages: [],
    unreadCount: 0
  };
  
  ROOMS.push(newRoom);
  addSystemMessage(`${currentUser.username} created this room`, newRoom);
  
  nameInput.value = '';
  descInput.value = '';
  
  closeModal('create-room-modal');
  renderRoomsList();
  showToast(`Room "${name}" created!`);
}

// ========== MODAL MANAGEMENT ==========

function openModal(modalId) {
  document.getElementById(modalId).classList.add('show');
}

function closeModal(modalId) {
  document.getElementById(modalId).classList.remove('show');
}

// ========== EXPORT CHAT ==========

function exportChat() {
  let text = `Chat Export - ${currentRoom.name}\n`;
  text += `Exported on: ${new Date().toLocaleString()}\n`;
  text += `${'='.repeat(50)}\n\n`;
  
  currentRoom.messages.forEach(msg => {
    if (msg.type === 'system') {
      text += `[SYSTEM] ${msg.text}\n`;
    } else {
      const time = formatTime(new Date(msg.timestamp));
      text += `[${time}] ${msg.username}: ${msg.text}\n`;
    }
  });
  
  const blob = new Blob([text], { type: 'text/plain' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `chat-${currentRoom.name}-${Date.now()}.txt`;
  a.click();
  URL.revokeObjectURL(url);
  
  showToast('Chat exported!');
}

// ========== SEARCH ==========

function searchMessages() {
  const query = document.getElementById('search-input').value.toLowerCase().trim();
  const resultsDiv = document.getElementById('search-results');
  
  if (!query) {
    resultsDiv.innerHTML = '<p style="color: var(--color-text-secondary); font-size: 14px;">Enter a keyword to search</p>';
    return;
  }
  
  const results = currentRoom.messages.filter(msg => 
    msg.type === 'message' && 
    !msg.deleted && 
    msg.text.toLowerCase().includes(query)
  );
  
  if (results.length === 0) {
    resultsDiv.innerHTML = '<p style="color: var(--color-text-secondary); font-size: 14px;">No messages found</p>';
    return;
  }
  
  resultsDiv.innerHTML = results.map(msg => {
    const time = formatTime(new Date(msg.timestamp));
    return `
      <div style="padding: 8px; margin-bottom: 8px; background: var(--color-secondary); border-radius: 6px;">
        <div style="font-weight: 500; color: ${msg.color}; margin-bottom: 4px;">${escapeHtml(msg.username)} <span style="font-size: 11px; color: var(--color-text-secondary);">• ${time}</span></div>
        <div style="font-size: 14px;">${escapeHtml(msg.text)}</div>
      </div>
    `;
  }).join('');
}

// ========== SETTINGS ==========

function toggleSetting(setting) {
  settings[setting] = !settings[setting];
  const toggle = document.getElementById(`toggle-${setting}`);
  if (settings[setting]) {
    toggle.classList.add('active');
  } else {
    toggle.classList.remove('active');
  }
  
  showToast(`${setting.charAt(0).toUpperCase() + setting.slice(1)} ${settings[setting] ? 'enabled' : 'disabled'}`);
}

// ========== NETWORK SIMULATION ==========

function updateConnectionStatus(status) {
  connectionStatus = status;
  const banner = document.getElementById('connection-banner');
  const statusText = document.getElementById('connection-status');
  
  banner.className = 'connection-banner ' + (status === 'connected' ? '' : status);
  
  const statusMap = {
    connected: 'Connected',
    connecting: 'Connecting...',
    disconnected: 'Disconnected',
    error: 'Connection Error'
  };
  
  statusText.textContent = statusMap[status] || 'Unknown';
}

function simulateNetworkActivity() {
  // Simulate occasional network events
  setInterval(() => {
    // Random user joins/leaves
    if (Math.random() > 0.95) {
      const randomRoom = ROOMS[Math.floor(Math.random() * ROOMS.length)];
      const user = SIMULATED_USERS[Math.floor(Math.random() * SIMULATED_USERS.length)];
      const userObj = allUsers[user.username];
      
      if (!randomRoom.users.find(u => u.id === userObj.id)) {
        randomRoom.users.push(userObj);
        addSystemMessage(`${user.username} joined the room`, randomRoom);
        if (randomRoom.id === currentRoom.id) {
          renderUsersList();
          renderMessages();
        }
      }
    }
    
    // Simulate message in other rooms
    if (Math.random() > 0.9) {
      const randomRoom = ROOMS.filter(r => r.id !== currentRoom.id)[Math.floor(Math.random() * (ROOMS.length - 1))];
      const user = SIMULATED_USERS[Math.floor(Math.random() * SIMULATED_USERS.length)];
      const userObj = allUsers[user.username];
      
      if (userObj && randomRoom) {
        const messages = ['Hey everyone!', 'Anyone here?', 'Check this out', 'Interesting...'];
        const msg = createMessage(messages[Math.floor(Math.random() * messages.length)], userObj, randomRoom);
        randomRoom.messages.push(msg);
        randomRoom.unreadCount++;
        renderRoomsList();
      }
    }
  }, 5000);
}

// ========== LOGOUT ==========

function logout() {
  if (!confirm('Are you sure you want to logout?')) return;
  
  // Remove user from rooms
  ROOMS.forEach(room => {
    const index = room.users.findIndex(u => u.id === currentUser.id);
    if (index !== -1) {
      room.users.splice(index, 1);
      addSystemMessage(`${currentUser.username} left the chat`, room);
    }
  });
  
  // Clear state
  delete allUsers[currentUser.username];
  currentUser = null;
  
  // Show login screen
  document.getElementById('chat-app').classList.remove('active');
  document.getElementById('login-screen').style.display = 'flex';
  document.getElementById('username').value = '';
}

// ========== EVENT LISTENERS ==========

document.addEventListener('DOMContentLoaded', () => {
  // Login
  document.getElementById('login-form').addEventListener('submit', handleLogin);
  
  // Message input
  const messageInput = document.getElementById('message-input');
  messageInput.addEventListener('input', () => {
    updateCharCount();
    handleTyping();
  });
  
  messageInput.addEventListener('keydown', (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      sendMessage();
    }
  });
  
  document.getElementById('send-btn').addEventListener('click', sendMessage);
  
  // Buttons
  document.getElementById('create-room-btn').addEventListener('click', () => openModal('create-room-modal'));
  document.getElementById('cancel-room-btn').addEventListener('click', () => closeModal('create-room-modal'));
  document.getElementById('confirm-room-btn').addEventListener('click', createNewRoom);
  
  document.getElementById('settings-btn').addEventListener('click', () => openModal('settings-modal'));
  document.getElementById('close-settings-btn').addEventListener('click', () => closeModal('settings-modal'));
  
  document.getElementById('search-btn').addEventListener('click', () => openModal('search-modal'));
  document.getElementById('close-search-btn').addEventListener('click', () => closeModal('search-modal'));
  document.getElementById('search-input').addEventListener('input', searchMessages);
  
  document.getElementById('export-btn').addEventListener('click', exportChat);
  document.getElementById('logout-btn').addEventListener('click', logout);
  
  // Settings toggles
  document.getElementById('toggle-notifications').addEventListener('click', () => toggleSetting('notifications'));
  document.getElementById('toggle-sound').addEventListener('click', () => toggleSetting('sound'));
  document.getElementById('toggle-autoscroll').addEventListener('click', () => toggleSetting('autoScroll'));
  
  // Close modals on overlay click
  document.querySelectorAll('.modal-overlay').forEach(overlay => {
    overlay.addEventListener('click', (e) => {
      if (e.target === overlay) {
        overlay.classList.remove('show');
      }
    });
  });
  
  // Keyboard shortcuts
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') {
      document.querySelectorAll('.modal-overlay.show').forEach(modal => {
        modal.classList.remove('show');
      });
    }
  });
  
  // Update typing indicator periodically
  setInterval(() => {
    renderTypingIndicator();
    renderUsersList();
  }, 1000);
});