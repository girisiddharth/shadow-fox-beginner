// In-Memory Library Management System (No localStorage, sessionStorage, or IndexedDB)
// Global In-Memory Database
let LIB_DB = {
  users: [], // { username, email, password, member_since, borrowed_books: [], returned_books: [], ratings: [], actions: [] }
  books: [], // [{...full book info incl. available, total, ratings: [ { user, rating } ]}]
  genres: [], // [list of strings]
  settings: { borrow_days: 14, max_books: 5, renewal_days: 7, late_fee_per_day: 0.5 },
  sessions: {}, // session management: { username }
  funfacts: [
    'Reading 20 minutes a day exposes you to 1.8 million words a year!',
    'People who read regularly live longer on average.',
    'The world’s largest library is the Library of Congress.',
    '“So many books, so little time.” — Frank Zappa',
    'The average novel has about 90,000 words.'
  ],
  motivationalQuotes: [
    '“A reader lives a thousand lives before he dies.” – George R.R. Martin',
    '“Books are uniquely portable magic.” – Stephen King',
    '“The only thing you absolutely have to know is the location of the library.” – Einstein',
    '“Once you learn to read, you will be forever free.” – Frederick Douglass',
    '“Reading is to the mind what exercise is to the body.” – Joseph Addison'
  ],
  staffPicks: [1, 7, 13, 18, 19] // Book IDs for staff picks
};

// Used to hold the session user in memory
let currentSessionUser = null;
let currentPage = 'login';
let navOpen = false;

// DOM Helpers
function $(sel) { return document.querySelector(sel); }
function $$(sel) { return Array.from(document.querySelectorAll(sel)); }
function escapeHTML(str) {
  return String(str).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
}

// App Initialization Data
const INIT_BOOKS = [
  { id: 1, title: "The Great Gatsby", author: "F. Scott Fitzgerald", isbn: "978-0743273565", genre: "Fiction", year: 1925, total: 5, available: 3, emoji: "📚", description: "A classic American novel set in the Jazz Age" },
  { id: 2, title: "To Kill a Mockingbird", author: "Harper Lee", isbn: "978-0061120084", genre: "Fiction", year: 1960, total: 4, available: 2, emoji: "📖", description: "A gripping tale of racial injustice and childhood innocence" },
  { id: 3, title: "1984", author: "George Orwell", isbn: "978-0451524935", genre: "Science", year: 1949, total: 6, available: 4, emoji: "📕", description: "A dystopian novel about totalitarianism and surveillance" },
  { id: 4, title: "Pride and Prejudice", author: "Jane Austen", isbn: "978-0141439518", genre: "Romance", year: 1813, total: 5, available: 2, emoji: "📗", description: "A witty romantic novel of manners and social commentary" },
  { id: 5, title: "The Catcher in the Rye", author: "J.D. Salinger", isbn: "978-0316769174", genre: "Fiction", year: 1951, total: 4, available: 3, emoji: "📘", description: "Coming-of-age story of a teenager navigating New York City" },
  { id: 6, title: "Sapiens", author: "Yuval Noah Harari", isbn: "978-0062316097", genre: "Non-Fiction", year: 2011, total: 5, available: 5, emoji: "📙", description: "A sweeping history of humankind from the Stone Age to modern times" },
  { id: 7, title: "A Brief History of Time", author: "Stephen Hawking", isbn: "978-0553382563", genre: "Science", year: 1988, total: 4, available: 3, emoji: "🔬", description: "Exploring black holes, the Big Bang, and the nature of time" },
  { id: 8, title: "The Da Vinci Code", author: "Dan Brown", isbn: "978-0307277671", genre: "Mystery", year: 2003, total: 5, available: 4, emoji: "🔍", description: "A thrilling mystery involving art, history, and conspiracy" },
  { id: 9, title: "Sherlock Holmes: Complete Collection", author: "Arthur Conan Doyle", isbn: "978-0307277671", genre: "Mystery", year: 1887, total: 3, available: 2, emoji: "🕵️", description: "Classic detective stories featuring the brilliant Sherlock Holmes" },
  { id: 10, title: "The Hobbit", author: "J.R.R. Tolkien", isbn: "978-0547928227", genre: "Fantasy", year: 1937, total: 4, available: 3, emoji: "🐉", description: "An epic fantasy adventure with hobbits, dragons, and treasure" },
  { id: 11, title: "Cosmos", author: "Carl Sagan", isbn: "978-0345539755", genre: "Science", year: 1980, total: 4, available: 2, emoji: "🌌", description: "A journey through space and time exploring the universe" },
  { id: 12, title: "Educated", author: "Tara Westover", isbn: "978-0399590504", genre: "Non-Fiction", year: 2018, total: 5, available: 4, emoji: "✏️", description: "A memoir about education and breaking free from a restrictive upbringing" },
  { id: 13, title: "The Midnight Library", author: "Matt Haig", isbn: "978-0525559474", genre: "Fiction", year: 2020, total: 5, available: 3, emoji: "✨", description: "A magical library where you can explore the lives you could have lived" },
  { id: 14, title: "Thinking, Fast and Slow", author: "Daniel Kahneman", isbn: "978-0374533557", genre: "Non-Fiction", year: 2011, total: 4, available: 2, emoji: "🧠", description: "Exploring how we think and make decisions" },
  { id: 15, title: "Atomic Habits", author: "James Clear", isbn: "978-0735211292", genre: "Non-Fiction", year: 2018, total: 6, available: 5, emoji: "💪", description: "Building better habits and breaking bad ones through tiny changes" },
  { id: 16, title: "The Silent Patient", author: "Alex Michaelides", isbn: "978-0451495068", genre: "Mystery", year: 2019, total: 5, available: 3, emoji: "🔐", description: "A psychological thriller about a woman who stops speaking" },
  { id: 17, title: "Dune", author: "Frank Herbert", isbn: "978-0441172719", genre: "Science", year: 1965, total: 4, available: 2, emoji: "🏜️", description: "Epic science fiction spanning political intrigue and ecological themes" },
  { id: 18, title: "Foundation", author: "Isaac Asimov", isbn: "978-0553293357", genre: "Science", year: 1951, total: 4, available: 4, emoji: "🏛️", description: "A visionary sci-fi series exploring psychohistory and the future of civilization" },
  { id: 19, title: "The Book Thief", author: "Markus Zusak", isbn: "978-0375831003", genre: "Fiction", year: 2005, total: 5, available: 3, emoji: "📚", description: "A moving story set in Nazi Germany told from Death's perspective" },
  { id: 20, title: "Guns, Germs, and Steel", author: "Jared Diamond", isbn: "978-0393317558", genre: "History", year: 1997, total: 4, available: 2, emoji: "🗺️", description: "Explaining how geography shaped the course of human history" },
  { id: 21, title: "The Silk Roads", author: "Peter Frankopan", isbn: "978-1400075461", genre: "History", year: 2015, total: 3, available: 2, emoji: "🛤️", description: "A new history of the world through the lens of trade routes" },
  { id: 22, title: "Braiding Sweetgrass", author: "Robin Wall Kimmerer", isbn: "978-1553171287", genre: "Non-Fiction", year: 2013, total: 4, available: 3, emoji: "🌿", description: "Indigenous wisdom and botanical insights about our relationship with nature" },
  { id: 23, title: "Neuromancer", author: "William Gibson", isbn: "978-0441569595", genre: "Science", year: 1984, total: 3, available: 2, emoji: "🤖", description: "Pioneering cyberpunk novel about hackers and artificial intelligence" },
  { id: 24, title: "The Name of the Wind", author: "Patrick Rothfuss", isbn: "978-0756404741", genre: "Fantasy", year: 2007, total: 4, available: 2, emoji: "⚔️", description: "Epic fantasy about a legendary figure recounting his extraordinary past" },
  { id: 25, title: "Circe", author: "Madeline Miller", isbn: "978-0316555661", genre: "Fantasy", year: 2018, total: 5, available: 4, emoji: "🧙", description: "A reimagining of Greek mythology from the goddess Circe's perspective" }
];
const INIT_GENRES = [
  'Fiction', 'Non-Fiction', 'Science', 'Mystery', 'History', 'Romance', 'Fantasy'
];
const INIT_USERS = [
  {
    username: "demo",
    email: "demo@library.com",
    password: "demo123",
    member_since: "2024-01-15",
    borrowed_books: [],
    returned_books: [],
    ratings: [],
    actions: [ { type: 'register', date: '2024-01-15' } ]
  },
  {
    username: "alex_reader",
    email: "alex@library.com",
    password: "password123",
    member_since: "2024-02-01",
    borrowed_books: [],
    returned_books: [],
    ratings: [],
    actions: [ { type: 'register', date: '2024-02-01' } ]
  },
  {
    username: "book_lover",
    email: "bookworm@library.com",
    password: "books123",
    member_since: "2024-03-10",
    borrowed_books: [],
    returned_books: [],
    ratings: [],
    actions: [ { type: 'register', date: '2024-03-10' } ]
  }
];

// 1. Initialize Demo Data in Memory - RUN ONCE per REFRESH
function setupDemoLibDB() {
  LIB_DB.books = JSON.parse(JSON.stringify(INIT_BOOKS));
  LIB_DB.genres = [...INIT_GENRES];
  LIB_DB.settings = { borrow_days: 14, max_books: 5, renewal_days: 7, late_fee_per_day: 0.50 };
  // Deep copy users, clear their borrowed_books arrays
  LIB_DB.users = JSON.parse(JSON.stringify(INIT_USERS));
  LIB_DB.sessions = {};
  // For demo: borrow a few books for demo user
  const d = LIB_DB.users[0];
  const today = new Date();
  function daysAgo(days) {
    const dt = new Date(today.getTime());
    dt.setDate(today.getDate() - days);
    return dt.toISOString();
  }
  // borrowed: miss one (overdue), return one, two active
  d.borrowed_books = [
    // Borrowed 10 days ago (still active)
    { bookId: 1, borrowDate: daysAgo(10), dueDate: daysAgo(-4), renewed: false },
    // Borrowed 16 days ago (overdue)
    { bookId: 4, borrowDate: daysAgo(16), dueDate: daysAgo(2), renewed: false },
    // Borrowed 2 days ago
    { bookId: 13, borrowDate: daysAgo(2), dueDate: daysAgo(12), renewed: false },
  ];
  d.returned_books = [
    // Already returned
    { bookId: 7, borrowDate: daysAgo(30), dueDate: daysAgo(16), returnedDate: daysAgo(13) }
  ];
  // Decrease available on borrowed, increase on return
  function adjustBook(bookId, type) {
    const b = LIB_DB.books.find(b => b.id === bookId);
    if (!b) return;
    if (type==='borrow') b.available = Math.max(0, b.available-1);
    if (type==='return') b.available = Math.min(b.total, b.available+1);
  }
  d.borrowed_books.forEach(bb => adjustBook(bb.bookId,'borrow'));
  d.returned_books.forEach(rb => adjustBook(rb.bookId,'return'));
}

// 2. Session Management
function loginSession(user) {
  currentSessionUser = user;
  LIB_DB.sessions = { username: user.username }; // emulate one session for demo
  renderNav();
  showMain();
}
function logoutSession() {
  currentSessionUser = null;
  LIB_DB.sessions = {};
  renderAuth('login');
}
function getSessionUser() {
  if (currentSessionUser) return currentSessionUser;
  if (LIB_DB.sessions && LIB_DB.sessions.username) {
    let u = LIB_DB.users.find(u => u.username === LIB_DB.sessions.username);
    if (u) { currentSessionUser = u; return u; }
  }
  return null;
}

// 3. Notification & Toasts
function notify(msg, type = 'info', dur=3000) {
  const el = document.getElementById('notification');
  el.className = `notification active ${type}`;
  el.querySelector('.notification-icon').textContent = type==='success'? '✓' : type==='error'? '✕' : 'ℹ';
  el.querySelector('.notification-message').textContent = msg;
  setTimeout(()=>{ el.classList.remove('active'); }, dur);
}

// 4. Modal helpers
function showModal(title, bodyHTML, actions=[]) {
  const modal = document.getElementById('modal');
  $('#modalTitle').textContent = title;
  $('#modalBody').innerHTML = bodyHTML;
  $('#modalActions').innerHTML = actions.map(a=>
    `<button class="btn ${escapeHTML(a.class)}" onclick="${a.onClick}">${a.text}</button>`
  ).join('');
  modal.classList.add('active');
}
function closeModal() {
  $('#modal').classList.remove('active');
}
window.onclick = function(event) {
  if (event.target === $('#modal')) closeModal();
}

// 5. Main Navigation (render only if logged in)
function renderNav() {
  const app = $('#app');
  if (!getSessionUser()) return;
  let navHTML = `
    <header class="header">
      <div class="header-content">
        <div class="logo">📚 Library System</div>
        <nav class="nav" id="mainnav">
          <a class="nav-link${currentPage === 'dashboard'? ' active':''}" onclick="navTo('dashboard')">Dashboard</a>
          <a class="nav-link${currentPage === 'browse'? ' active':''}" onclick="navTo('browse')">Browse Books</a>
          <a class="nav-link${currentPage === 'mybooks'? ' active':''}" onclick="navTo('mybooks')">My Books</a>
          <a class="nav-link${currentPage === 'recommendations' ? ' active':''}" onclick="navTo('recommendations')">Recommendations</a>
          <a class="nav-link${currentPage === 'profile' ? ' active':''}" onclick="navTo('profile')">Profile</a>
          <a class="nav-link" onclick="logoutSession()">Logout</a>
        </nav>
        <button aria-label="menu" class="navburger" style="display:none;" onclick="toggleNav()">☰</button>
      </div>
    </header>
  `;
  app.innerHTML = navHTML + '<main id="mainContent" class="main-content"></main>';
}
function navTo(page) {
  currentPage = page;
  showMain();
  if(window.innerWidth<768)closeNav();
}
function toggleNav() {
  navOpen = !navOpen;
  const nav = document.getElementById('mainnav');
  if(nav) nav.style.display = navOpen ? 'flex':'none';
}
function closeNav() {
  navOpen=false;
  const nav = document.getElementById('mainnav');
  if(nav) nav.style.display = '';
}
window.addEventListener('resize', () => {
  if(window.innerWidth > 768) closeNav();
});

// 6. Auth Pages (login/register)
function renderAuth(page) {
  currentPage = page;
  const app = $('#app');
  app.innerHTML = `
    <div class="auth-container">
      <div class="auth-card">
        <div class="auth-header">
          <div class="logo">📚 Library System</div>
          <h1 class="auth-title">${page==='login'? 'Welcome Back' : 'Create Account'}</h1>
          <div class="auth-subtitle">
            ${page==='login'
              ? 'Sign in to your account'
              : 'Join our library community'}
          </div>
        </div>
        <form id="${page==='login'?'loginForm':'registerForm'}">
          ${page==='register'?`
          <div class="form-group">
            <label class="form-label">Username</label>
            <input type="text" id="regUsername" class="form-control" placeholder="Choose a username" required>
          </div>
          <div class="form-group">
            <label class="form-label">Email</label>
            <input type="email" id="regEmail" class="form-control" placeholder="Enter your email" required>
          </div>
          <div class="form-group">
            <label class="form-label">Password</label>
            <input type="password" id="regPassword" class="form-control" placeholder="At least 6 characters" required>
          </div>
          <div class="form-group">
            <label class="form-label">Confirm Password</label>
            <input type="password" id="regConfirmPassword" class="form-control" placeholder="Re-enter password" required>
          </div>
          `: `
          <div class="form-group">
            <label class="form-label">Username or Email</label>
            <input type="text" id="loginUsername" class="form-control" placeholder="Enter your username/email" required>
          </div>
          <div class="form-group">
            <label class="form-label">Password</label>
            <input type="password" id="loginPassword" class="form-control" placeholder="Enter your password" required>
          </div>
          `}
          <button type="submit" class="btn btn-primary">${page==='login'?'Sign In':'Create Account'}</button>
        </form>
        <div class="auth-switch">
          ${page==='login'? `Don't have an account? <a onclick="renderAuth('register')">Register here</a>`:
          `Already have an account? <a onclick="renderAuth('login')">Sign In</a>`}
        </div>
        <div class="auth-switch" style="margin-top: 12px; font-size: 11px; color: var(--color-text-secondary);">
          Demo: username: <strong>demo</strong> / password: <strong>demo123</strong>
        </div>
        <div class="auth-switch" style="margin-top: 12px; font-size: 11px; color: var(--color-text-secondary);">
          <em>All demo data resets on page refresh</em>
        </div>
      </div>
    </div>
  `;
  if(page==='register') {
    $('#registerForm').onsubmit = handleRegister;
  } else {
    $('#loginForm').onsubmit = handleLogin;
  }
}

// Auth logic
function handleLogin(e) {
  e.preventDefault();
  const s = $('#loginUsername').value.trim();
  const p = $('#loginPassword').value;
  let u = LIB_DB.users.find(u =>
    u.username.toLowerCase() === s.toLowerCase() || u.email.toLowerCase() === s.toLowerCase()
  );
  if (!u || u.password !== p) {
    notify('Invalid username/email or password', 'error');
    return;
  }
  loginSession(u);
  notify('Login successful!', 'success');
}
function handleRegister(e) {
  e.preventDefault();
  const username = $('#regUsername').value.trim();
  const email = $('#regEmail').value.trim();
  const pw = $('#regPassword').value;
  const cpw = $('#regConfirmPassword').value;
  if (!username || !email || !pw || !cpw) {
    notify('All fields required', 'error');
    return;
  }
  if (pw.length < 6) { notify('Password must be 6+ characters', 'error'); return; }
  if (pw !== cpw) { notify('Passwords do not match', 'error'); return; }
  if (LIB_DB.users.some(u => u.username.toLowerCase() === username.toLowerCase())) {
    notify('Username already exists', 'error');
    return;
  }
  if (LIB_DB.users.some(u => u.email.toLowerCase() === email.toLowerCase())) {
    notify('Email already registered', 'error');
    return;
  }
  let member_since = new Date().toISOString().slice(0,10);
  let u = { username, email, password: pw, member_since,
    borrowed_books: [], returned_books: [], ratings: [], actions: [ {type:'register', date:member_since} ] };
  LIB_DB.users.push(u);
  notify('Registered! You can now sign in.', 'success');
  setTimeout(()=>renderAuth('login'),1250);
}

// ===================== MAIN PAGES =======================
function showMain() {
  const main = $('#mainContent');
  if (!main) { renderNav(); return showMain(); }
  switch(currentPage) {
    case 'dashboard': return pageDashboard(main);
    case 'browse': return pageBrowse(main);
    case 'mybooks': return pageMyBooks(main);
    case 'recommendations': return pageRecommendations(main);
    case 'profile': return pageProfile(main);
    default: return pageDashboard(main);
  }
}

// Dashboard
function pageDashboard(main) {
  const user = getSessionUser();
  if (!user) return renderAuth('login');
  let borrowed = user.borrowed_books;
  let returned = user.returned_books;
  let totalBorrowed = borrowed.length + returned.length;
  let streak = borrowed.length > 0 ? countReadingStreak(user) : 0;
  let statsCards = `
    <div class="stats-grid">
      <div class="stat-card"><div class="stat-icon">📚</div><div class="stat-value">${borrowed.length}</div><div class="stat-label">Currently Borrowed</div></div>
      <div class="stat-card"><div class="stat-icon">✓</div><div class="stat-value">${returned.length}</div><div class="stat-label">Books Returned</div></div>
      <div class="stat-card"><div class="stat-icon">📅</div><div class="stat-value">${user.member_since}</div><div class="stat-label">Member Since</div></div>
      <div class="stat-card"><div class="stat-icon">🔥</div><div class="stat-value">${streak}</div><div class="stat-label">Day Reading Streak</div></div>
    </div>
  `;
  let msg = milestoneMessage(totalBorrowed);
  let funfact = LIB_DB.funfacts[ Math.floor(Math.random()*LIB_DB.funfacts.length) ];
  let quote = LIB_DB.motivationalQuotes[ Math.floor(Math.random()*LIB_DB.motivationalQuotes.length) ];
  main.innerHTML = `
    <div class="dashboard-header">
      <h1 class="dashboard-title">Welcome, ${escapeHTML(user.username)}! 👋</h1>
      <p class="dashboard-subtitle">Here's your library overview.<br><span style='color:var(--color-info);'>${msg||''}</span></p>
    </div>
    ${statsCards}
    <div class="section-title">Quick Actions</div>
    <div style="display:flex; gap:16px; flex-wrap:wrap; margin-bottom:28px;">
      <button class="btn btn-primary" onclick="navTo('browse')">Browse Books</button>
      <button class="btn btn-secondary" onclick="navTo('mybooks')">My Books</button>
      <button class="btn btn-secondary" onclick="navTo('recommendations')">Recommendations</button>
      <button class="btn btn-secondary" onclick="navTo('profile')">Profile</button>
    </div>
    <div class="section-title">Currently Reading</div>
    <div class="books-grid">
      ${borrowed.length>0 ? borrowed.slice(0,4).map(bb=>renderBookCard(bb.bookId,true)).join('') : `<div class='empty-state'><div class='empty-icon'>📚</div><div class='empty-title'>No books are borrowed.</div></div>`}
    </div>
    <hr style='margin:36px 0'>
    <div style='margin-top:28px;color:var(--color-primary);font-size:18px;'><strong>Motivational Quote:</strong> <span style='color:var(--color-info);'>${quote}</span></div>
    <div style='color:var(--color-text-secondary);margin-top:8px;'><em>Did you know?</em> ${funfact}</div>
  `;
}
function milestoneMessage(total) {
  if (total >= 50) return `Wow! You borrowed 50+ books - you are a Book Master! 🏆`;
  if (total >= 20) return `You broke 20 books borrowed! Keep reading! 🚀`;
  if (total >= 10) return `You borrowed 10 books – amazing consistency! ✨`;
  if (total >= 5) return `5 books read already – keep up the streak! 🔥`;
  return '';
}
function countReadingStreak(user) { // Days since last missed day
  let allDays = user.borrowed_books.concat(user.returned_books).map(b=>b.borrowDate.slice(0,10));
  allDays.sort((a,b) => b.localeCompare(a));
  let streak = 0, cur = (new Date()).toISOString().slice(0,10);
  for(let i=0;i<allDays.length;i++){
    if (cur === allDays[i]) { streak++; cur = offsetDate(cur, -1); } else break;
  }
  return streak;
}
function offsetDate(dt, days) {
  let d = new Date(dt); d.setDate(d.getDate() + days); return d.toISOString().slice(0,10);
}

// Browse Books
function pageBrowse(main) {
  const user = getSessionUser();
  let genreOpts = `<option value="">All</option>`+LIB_DB.genres.map(g=>`<option value="${g}">${g}</option>`).join('');
  main.innerHTML = `
    <div class="dashboard-header">
      <h1 class="dashboard-title">Browse Books</h1>
      <p class="dashboard-subtitle">Search, filter, or borrow your next book.</p>
    </div>
    <div class="search-filter-bar">
      <div class="search-box"><input id="searchInput" class="search-input" placeholder="Search by title or author…" oninput="renderBookGrid()"></div>
      <select id="genreFilter" class="filter-select" onchange="renderBookGrid()">${genreOpts}</select>
    </div>
    <div id="booksContainer" class="books-grid"></div>
  `;
  renderBookGrid();
}
function renderBookGrid() {
  const inp = ($('#searchInput')||{}).value || '';
  const genre = ($('#genreFilter')||{}).value || '';
  let filterFn = b => (
    (!inp || b.title.toLowerCase().includes(inp.toLowerCase()) || b.author.toLowerCase().includes(inp.toLowerCase())) &&
    (!genre || b.genre === genre)
  );
  let books = LIB_DB.books.filter(filterFn);
  const user = getSessionUser();
  let html = books.length ? books.map(b=>renderBookCard(b.id,false,user)).join('') : `<div class='empty-state'><div class='empty-icon'>🔍</div><div class='empty-title'>No books found</div></div>`;
  $('#booksContainer').innerHTML = html;
}
function renderBookCard(bookId,my=false,curUser) {
  const book = LIB_DB.books.find(b=>b.id===bookId);
  const user = curUser || getSessionUser();
  const isBorrowed = user && user.borrowed_books.some(bb=>bb.bookId===bookId);
  let borrowedInfo = '';
  if (my && user) {
    const bb = user.borrowed_books.find(bb=>bb.bookId===bookId);
    const due = (new Date(bb.dueDate));
    const now = (new Date());
    const daysRem = Math.ceil((due-now)/86400000);
    borrowedInfo = `<div style='font-size:13px; color:${daysRem<0?'var(--color-error)':'var(--color-primary)'};'>${daysRem<0?'Overdue '+(-daysRem)+'d':daysRem+' days left'}</div>`;
  }
  return `<div class='book-card' onclick='showBookModal(${book.id})'>
    <div class='book-cover'>${book.emoji}</div>
    <div class='book-title'>${escapeHTML(book.title)}</div>
    <div class='book-author'>by ${escapeHTML(book.author)}</div>
    <div class='book-meta'>
      <span class='book-genre'>${escapeHTML(book.genre)}</span> <span class='book-available ${book.available>0? '':'book-unavailable'}'>${book.available>0?'✓':'✕'} ${book.available} available</span>
    </div>
    ${borrowedInfo}
    <div class='book-actions'>
      ${isBorrowed? `<button class='btn btn-secondary btn-small' disabled>Borrowed</button>`:
      `<button class='btn btn-primary btn-small' onclick='event.stopPropagation(); borrowBook(${book.id})' ${book.available<=0?'disabled':''} >Borrow Book</button>`}
    </div>
  </div>`;
}
function showBookModal(bookId) {
  const book = LIB_DB.books.find(b=>b.id===bookId);
  const ratings = book.ratings||[];
  const avg = ratings.length? Math.round(10* ratings.reduce((s,r)=>s+r.rating,0)/ratings.length)/10 : null;
  showModal(book.title,
    `<div style='text-align:center;margin-bottom:12px;'>
      <div style='font-size:56px;margin-bottom:6px;'>${book.emoji}</div>
      <div style='color:var(--color-text-secondary);margin-bottom:15px;'>by ${book.author}</div>
    </div>
    <div><strong>ISBN:</strong> ${book.isbn}</div>
    <div><strong>Genre:</strong> ${book.genre}</div>
    <div><strong>Published:</strong> ${book.year}</div>
    <div><strong>Description:</strong> <em>${escapeHTML(book.description||'No description.')}</em></div>
    <div style='margin:10px 0 0 0;'>
      <strong style='vertical-align:middle;'>Rating:</strong> ${avg? renderStars(avg) : 'No ratings yet'}
    </div>
  `,
  [ { text:'Close', class:'btn-secondary', onClick:'closeModal()'}
    , book.available>0? {text:'Borrow', class:'btn-primary', onClick:`borrowBook(${book.id})`} : null
  ].filter(Boolean));
}
function renderStars(av){
  let s='';for(let i=1;i<=5;i++)s+=`<span style='color:${i<=av?'gold':'#bbb'}'>&#9733;</span>`;return s+` <span style='font-size:12px; color:var(--color-text-secondary);'>(${av})</span>`;
}

// ================= My Books ===================
function pageMyBooks(main) {
  const user = getSessionUser();
  let my = user.borrowed_books;
  main.innerHTML = `
    <div class="dashboard-header">
      <h1 class="dashboard-title">My Books</h1>
      <p class="dashboard-subtitle">Books you have borrowed</p>
    </div>
    <div class="table-container"><table class='table'>
      <thead><tr><th>Book</th><th>Borrowed</th><th>Due</th><th>Status</th><th>Action</th></tr></thead>
      <tbody>
         ${my.length? my.map(bb=>renderBorrowedTable(bb,user)).join(''): `<tr><td colspan='5'><div class='empty-state'><div class='empty-icon'>📚</div><div class='empty-title'>No borrowed books</div></div></td></tr>`}
      </tbody>
    </table></div>
  `;
}
function renderBorrowedTable(bb,user) {
  const book = LIB_DB.books.find(b=>b.id===bb.bookId);
  const due = new Date(bb.dueDate), now = new Date();
  const daysRem = Math.ceil((due-now)/86400000);
  return `<tr${daysRem<0?" class='overdue'":''}><td>
    <div style='display:flex;align-items:center;gap:10px;'><span style='font-size:22px;'>${book.emoji}</span><span>${escapeHTML(book.title)}</span></div></td>
    <td>${escapeHTML(bb.borrowDate.slice(0,10))}</td>
    <td>${escapeHTML(bb.dueDate.slice(0,10))}</td>
    <td><span style='color:${daysRem<0?'var(--color-error)':'var(--color-success)'};font-weight:500;'>
      ${daysRem<0?'Overdue': daysRem+' days'}</span></td>
    <td><button class='btn btn-secondary btn-small' onclick='returnBook(${book.id})'>Return</button</td></tr>`;
}
function borrowBook(bookId) {
  const user = getSessionUser();
  if (!user) return notify('You must be logged in','error');
  if (user.borrowed_books.length>=LIB_DB.settings.max_books)
    return notify(`Borrow limit (${LIB_DB.settings.max_books}) reached!`, 'error');
  const book = LIB_DB.books.find(b=>b.id===bookId);
  if (book.available<=0)
    return notify('Book not available now','error');
  if (user.borrowed_books.some(bb=>bb.bookId===book.id))
    return notify('You already borrowed this book','error');
  book.available--;
  let now = new Date(), due = new Date(now);
  due.setDate(now.getDate()+LIB_DB.settings.borrow_days);
  user.borrowed_books.push({
    bookId: book.id, borrowDate: now.toISOString(), dueDate: due.toISOString(), renewed: false
  });
  user.actions.push({type:'borrow', bookId:book.id, date: now.toISOString()});
  notify('Enjoy your book!','success');
  showMain();
  closeModal();
}
function returnBook(bookId) {
  const user = getSessionUser();
  const idx = user.borrowed_books.findIndex(bb=>bb.bookId===bookId);
  if (idx===-1) return notify('Book not found in your borrowed list','error');
  const bb = user.borrowed_books[idx];
  user.borrowed_books.splice(idx,1);
  const book = LIB_DB.books.find(b=>b.id===bookId);
  book.available = Math.min(book.total, book.available+1);
  bb.returnedDate = new Date().toISOString();
  user.returned_books.push(bb);
  user.actions.push({type:'return', bookId, date: bb.returnedDate});
  notify('Book returned!','success');
  showMain();
  closeModal();
}
// ================= Recommendations Page ===============
function pageRecommendations(main) {
  const user = getSessionUser();
  // Analyze user's genres
  let genresBorrowed = user.returned_books.concat(user.borrowed_books).map(bb=>{
    let b = LIB_DB.books.find(bk=>bk.id===bb.bookId); return b?b.genre:null;
  }).filter(Boolean);
  let mostReadGenre = genresBorrowed.length ?
     genresBorrowed.sort((a,b) => genresBorrowed.filter(v=>v===a).length - genresBorrowed.filter(v=>v===b).length ).pop() : null;
  // Personalized recommendations
  let recBooks = LIB_DB.books.filter(b=>(
    b.genre===mostReadGenre && !user.borrowed_books.concat(user.returned_books).some(bb=>bb.bookId===b.id) && b.available>0
  ));
  // Popular (most borrowed this month) -- for demo, show top 5 with least available
  let popBooks = [...LIB_DB.books].sort((a,b)=>a.available-b.available).slice(0,5);
  // New arrivals: year >= 2018
  let newArr = LIB_DB.books.filter(b=>b.year>=2018).sort((a,b)=>b.year-a.year).slice(0,5);
  // Staff picks
  let staff = LIB_DB.staffPicks.map(id=>LIB_DB.books.find(b=>b.id===id)).filter(Boolean);
  main.innerHTML = `
    <div class='dashboard-header'>
      <h1 class='dashboard-title'>Recommendations</h1>
      <p class='dashboard-subtitle'>Personalized picks for ${escapeHTML(user.username)}</p>
    </div>
    <div class='recommendations-section'><h2 class='section-title'>Based on Your Reading</h2>
      <div class='books-grid'>${recBooks.length? recBooks.map(b=>renderBookCard(b.id)).join(''):`<div class='empty-state'>Nothing matched your past reads. Try borrowing a book to get recommendations!</div>`}</div>
    </div>
    <div class='recommendations-section'><h2 class='section-title'>Popular This Month</h2>
      <div class='books-grid'>${popBooks.map(b=>renderBookCard(b.id)).join('')}</div>
    </div>
    <div class='recommendations-section'><h2 class='section-title'>New Arrivals</h2>
      <div class='books-grid'>${newArr.map(b=>renderBookCard(b.id)).join('')}</div>
    </div>
    <div class='recommendations-section'><h2 class='section-title'>Staff Picks</h2>
      <div class='books-grid'>${staff.map(b=>renderBookCard(b.id)).join('')}</div>
    </div>
  `;
}

// ================= Profile Page ========================
function pageProfile(main) {
  const user = getSessionUser();
  let stats = {
    totalBorrowed: user.borrowed_books.length + user.returned_books.length,
    currentlyBorrowed: user.borrowed_books.length,
    returned: user.returned_books.length,
    avgPerMonth: avgBooksPerMonth(user),
  };
  // Activity timeline (last 10 actions)
  let actHTML = user.actions.slice(-10).map((a,idx)=> {
    const b = LIB_DB.books.find(bk=>bk.id===a.bookId)||{};
    return `<div style='font-size:13px;margin:2px 0;'>${a.date.slice(0,10)} – ${a.type==='borrow'?`Borrowed <b>${escapeHTML(b.title||'')}</b>`: a.type==='return'?`Returned <b>${escapeHTML(b.title||'')}</b>`:'Registered'} </div>`;
  }).reverse().join('');
  // Borrowing history table
  let histRows = user.returned_books.slice(-10).map(bb=> {
    const b = LIB_DB.books.find(bk=>bk.id===bb.bookId);
    const borrowDate = bb.borrowDate.slice(0,10);
    const returnDate = bb.returnedDate? bb.returnedDate.slice(0,10):'';
    let ratingLine = `<button class='btn btn-secondary btn-small' onclick='rateBook(${b.id})'>Rate</button>`;
    let userRating = getUserRating(user,b.id);
    if (userRating) ratingLine = renderStars(userRating.rating)+ ' Thank you!';
    return `<tr><td>${b.emoji} ${escapeHTML(b.title)}</td><td>${borrowDate}</td><td>${returnDate}</td><td>${ratingLine}</td></tr>`;
  }).join('');
  main.innerHTML = `
    <div class='dashboard-header'>
      <h1 class='dashboard-title'>My Profile</h1>
      <p class='dashboard-subtitle'>Your library stats and settings</p>
    </div>
    <div class='profile-container'>
      <div class='profile-card'>
        <div class='profile-avatar'>${user.username[0].toUpperCase()}</div>
        <div class='profile-name'>${escapeHTML(user.username)}</div>
        <div class='profile-email'>${escapeHTML(user.email)}</div>
        <div class='profile-info'>
          <div class='profile-info-item'><span class='profile-info-label'>Member Since</span><span class='profile-info-value'>${user.member_since}</span></div>
          <div class='profile-info-item'><span class='profile-info-label'>Total Borrowed</span><span class='profile-info-value'>${stats.totalBorrowed}</span></div>
          <div class='profile-info-item'><span class='profile-info-label'>Currently Borrowed</span><span class='profile-info-value'>${stats.currentlyBorrowed}</span></div>
          <div class='profile-info-item'><span class='profile-info-label'>Books Returned</span><span class='profile-info-value'>${stats.returned}</span></div>
          <div class='profile-info-item'><span class='profile-info-label'>Avg/Month</span><span class='profile-info-value'>${stats.avgPerMonth}</span></div>
        </div>
      </div>
      <div>
        <div class='profile-card'>
          <h3 class='section-title'>Borrowing History</h3>
          <div class='table-container'><table class='table'><thead><tr><th>Book</th><th>Borrowed</th><th>Returned</th><th>Rating</th></tr></thead><tbody>${histRows||'<tr><td colspan=4>(none yet)</td></tr>'}</tbody></table></div>
          <h3 class='section-title' style='margin-top:16px;'>Activity Timeline</h3>
          <div>${actHTML||'<div>(No recent activity)</div>'}</div>
        </div>
        <div class='profile-card'>
          <h3 class='section-title'>Data Import/Export</h3>
          <button class='btn btn-primary' onclick='exportData()'>Export My Data</button>
          <input id='importFile' type='file' style='display:none' accept='.json'>
          <button class='btn btn-secondary' onclick='$("#importFile").click()'>Import Data</button>
        </div>
        <div class='profile-card'>
          <h3 class='section-title'>Account Settings</h3>
          <button class='btn btn-secondary btn-small' onclick='editProfileForm()'>Edit Profile</button>
        </div>
      </div>
    </div>
  `;
  $('#importFile').onchange = importData;
}
function avgBooksPerMonth(user) {
  let ms = (new Date()-new Date(user.member_since+"T00:00"))/(1000*60*60*24*30.42);
  ms = Math.max(ms, 1/12);
  return (user.borrowed_books.length + user.returned_books.length === 0)?0: (Math.round((user.borrowed_books.length+user.returned_books.length)/ms * 10)/10);
}
function editProfileForm() {
  const user = getSessionUser();
  showModal('Edit Profile',
    `<div class='form-group'><label>Email:</label><input id='editEmail' class='form-control' value='${escapeHTML(user.email)}'></div>
     <div class='form-group'><label>New Password:</label><input type='password' id='editPw' class='form-control' placeholder='Leave blank to keep unchanged'></div>
    `,
    [
      { text: 'Save', class: 'btn-primary', onClick: 'saveProfileEdit()'},
      { text: 'Cancel', class: 'btn-secondary', onClick: 'closeModal()'}
    ]
  );
}
function saveProfileEdit() {
  const user = getSessionUser();
  let email = $('#editEmail').value.trim();
  let pw = $('#editPw').value;
  if (!email) return notify('Email required','error');
  if (pw && pw.length < 6) return notify('Password: 6+ chars','error');
  if (LIB_DB.users.some(u=>u.email===email && u.username!==user.username))
    return notify('Email taken','error');
  user.email = email;
  if (pw) user.password = pw;
  notify('Profile updated!','success');
  closeModal();
  showMain();
}
// Data import/export
function exportData() {
  const user = getSessionUser();
  const exp = JSON.stringify(user);
  const b = new Blob([exp], {type:'application/json'});
  const a = document.createElement('a');
  a.href = URL.createObjectURL(b);
  a.download = `profile_${user.username}.json`;
  a.click();
  notify('Data exported!','success');
}
function importData(ev) {
  const file = ev.target.files[0];
  if (!file) return;
  let reader = new FileReader();
  reader.onload = function(e) {
    try {
      const imported = JSON.parse(e.target.result);
      if (!imported.username) throw Error('Invalid profile data');
      // Replace user data
      let idx = LIB_DB.users.findIndex(u=>u.username===imported.username);
      if (idx>=0) LIB_DB.users[idx] = imported;
      if (currentSessionUser && imported.username===currentSessionUser.username)
        currentSessionUser = imported;
      notify('Profile imported!','success');
      showMain();
    }catch(err){
      notify('Import failed: '+err.message,'error');
    }
  };
  reader.readAsText(file);
}

// Rating
function rateBook(bookId) {
  showModal('Rate Book',
    '<div class="form-group">How many stars (1-5)?<br><input id=rateVal min=1 max=5 type=number class=form-control style="width:60px"></div>',
    [ {text:'Rate', class:'btn-primary',onClick:`saveRating(${bookId})`},
    {text:'Cancel', class:'btn-secondary',onClick:'closeModal()'} ]
  );
}
function saveRating(bookId) {
  let val = Math.max(1, Math.min(5, parseInt($('#rateVal').value,10)||3));
  const user = getSessionUser();
  let entry = getUserRating(user,bookId);
  if (entry) entry.rating = val;
  else user.ratings.push({bookId,rating:val});
  // Save to global book ratings
  const book = LIB_DB.books.find(b=>b.id===bookId);
  if (!book.ratings) book.ratings=[];
  let br = book.ratings.find(r=>r.user===user.username);
  if (br) br.rating=val; else book.ratings.push({user:user.username, rating:val});
  notify('Thank you for rating!','success');
  closeModal();
  showMain();
}
function getUserRating(user,bookId){
  return user.ratings.find(r=>r.bookId===bookId);
}

// ============= BOOTSTRAP ================
function appBoot() {
  setupDemoLibDB();
  if (getSessionUser()) {
    renderNav();
    showMain();
  } else {
    renderAuth('login');
  }
}
window.addEventListener('DOMContentLoaded',appBoot);
