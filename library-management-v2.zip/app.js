// Library Management System

// Database setup
let db;
const DB_NAME = 'LibraryDB';
const DB_VERSION = 1;

// Sample data
const SAMPLE_BOOKS = [
  { id: 1, title: "The Great Gatsby", author: "F. Scott Fitzgerald", isbn: "978-0743273565", genre: "Fiction", year: 1925, available: 3, image: "📚" },
  { id: 2, title: "To Kill a Mockingbird", author: "Harper Lee", isbn: "978-0061120084", genre: "Fiction", year: 1960, available: 2, image: "📖" },
  { id: 3, title: "1984", author: "George Orwell", isbn: "978-0451524935", genre: "Science", year: 1949, available: 4, image: "📕" },
  { id: 4, title: "Pride and Prejudice", author: "Jane Austen", isbn: "978-0141439518", genre: "Fiction", year: 1813, available: 2, image: "📗" },
  { id: 5, title: "The Catcher in the Rye", author: "J.D. Salinger", isbn: "978-0316769174", genre: "Fiction", year: 1951, available: 3, image: "📘" },
  { id: 6, title: "Sapiens", author: "Yuval Noah Harari", isbn: "978-0062316097", genre: "Non-Fiction", year: 2011, available: 5, image: "📙" },
  { id: 7, title: "A Brief History of Time", author: "Stephen Hawking", isbn: "978-0553382563", genre: "Science", year: 1988, available: 3, image: "📚" },
  { id: 8, title: "The Da Vinci Code", author: "Dan Brown", isbn: "978-0307277671", genre: "Mystery", year: 2003, available: 4, image: "📖" },
  { id: 9, title: "Sherlock Holmes", author: "Arthur Conan Doyle", isbn: "978-0307277671", genre: "Mystery", year: 1887, available: 2, image: "🕵️" },
  { id: 10, title: "The Hobbit", author: "J.R.R. Tolkien", isbn: "978-0547928227", genre: "Fiction", year: 1937, available: 3, image: "📕" },
  { id: 11, title: "Cosmos", author: "Carl Sagan", isbn: "978-0345539755", genre: "Science", year: 1980, available: 2, image: "🔭" },
  { id: 12, title: "Educated", author: "Tara Westover", isbn: "978-0399590504", genre: "Non-Fiction", year: 2018, available: 4, image: "📗" },
  { id: 13, title: "The Midnight Library", author: "Matt Haig", isbn: "978-0525559474", genre: "Fiction", year: 2020, available: 3, image: "📘" },
  { id: 14, title: "Thinking Fast and Slow", author: "Daniel Kahneman", isbn: "978-0374533557", genre: "Non-Fiction", year: 2011, available: 2, image: "🧠" },
  { id: 15, title: "Atomic Habits", author: "James Clear", isbn: "978-0735211292", genre: "Non-Fiction", year: 2018, available: 5, image: "💪" },
  { id: 16, title: "The Silent Patient", author: "Alex Michaelides", isbn: "978-0451495068", genre: "Mystery", year: 2019, available: 3, image: "🔐" },
  { id: 17, title: "Dune", author: "Frank Herbert", isbn: "978-0441172719", genre: "Science", year: 1965, available: 2, image: "🌵" },
  { id: 18, title: "Foundation", author: "Isaac Asimov", isbn: "978-0553293357", genre: "Science", year: 1951, available: 4, image: "🏛️" },
  { id: 19, title: "The Book Thief", author: "Markus Zusak", isbn: "978-0375831003", genre: "Fiction", year: 2005, available: 3, image: "📚" },
  { id: 20, title: "Guns Germs and Steel", author: "Jared Diamond", isbn: "978-0393317558", genre: "History", year: 1997, available: 2, image: "🗺️" }
];

const GENRES = ['All', 'Fiction', 'Non-Fiction', 'Science', 'Mystery', 'History'];
const BORROW_DAYS = 14;
const MAX_BORROW_LIMIT = 5;

// State management
let currentUser = null;
let currentPage = 'login';
let allBooks = [];
let userBorrowedBooks = [];

// Initialize IndexedDB
function initDB() {
  return new Promise((resolve, reject) => {
    const request = indexedDB.open(DB_NAME, DB_VERSION);

    request.onerror = () => reject(request.error);
    request.onsuccess = () => {
      db = request.result;
      resolve(db);
    };

    request.onupgradeneeded = (event) => {
      db = event.target.result;

      // Create object stores
      if (!db.objectStoreNames.contains('users')) {
        const userStore = db.createObjectStore('users', { keyPath: 'username' });
        userStore.createIndex('email', 'email', { unique: true });
      }

      if (!db.objectStoreNames.contains('books')) {
        db.createObjectStore('books', { keyPath: 'id' });
      }

      if (!db.objectStoreNames.contains('borrowings')) {
        const borrowStore = db.createObjectStore('borrowings', { keyPath: 'id', autoIncrement: true });
        borrowStore.createIndex('username', 'username', { unique: false });
        borrowStore.createIndex('bookId', 'bookId', { unique: false });
      }
    };
  });
}

// Database operations
function addData(storeName, data) {
  return new Promise((resolve, reject) => {
    const transaction = db.transaction([storeName], 'readwrite');
    const store = transaction.objectStore(storeName);
    const request = store.add(data);

    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error);
  });
}

function getData(storeName, key) {
  return new Promise((resolve, reject) => {
    const transaction = db.transaction([storeName], 'readonly');
    const store = transaction.objectStore(storeName);
    const request = store.get(key);

    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error);
  });
}

function getAllData(storeName) {
  return new Promise((resolve, reject) => {
    const transaction = db.transaction([storeName], 'readonly');
    const store = transaction.objectStore(storeName);
    const request = store.getAll();

    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error);
  });
}

function updateData(storeName, data) {
  return new Promise((resolve, reject) => {
    const transaction = db.transaction([storeName], 'readwrite');
    const store = transaction.objectStore(storeName);
    const request = store.put(data);

    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error);
  });
}

function deleteData(storeName, key) {
  return new Promise((resolve, reject) => {
    const transaction = db.transaction([storeName], 'readwrite');
    const store = transaction.objectStore(storeName);
    const request = store.delete(key);

    request.onsuccess = () => resolve();
    request.onerror = () => reject(request.error);
  });
}

function getDataByIndex(storeName, indexName, value) {
  return new Promise((resolve, reject) => {
    const transaction = db.transaction([storeName], 'readonly');
    const store = transaction.objectStore(storeName);
    const index = store.index(indexName);
    const request = index.getAll(value);

    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error);
  });
}

// Initialize books in database
async function initializeBooks() {
  const books = await getAllData('books');
  if (books.length === 0) {
    for (const book of SAMPLE_BOOKS) {
      await addData('books', book);
    }
  }
  allBooks = await getAllData('books');
}

// Auth functions
async function register(username, email, password, confirmPassword) {
  if (!username || !email || !password) {
    showNotification('All fields are required', 'error');
    return false;
  }

  if (password.length < 6) {
    showNotification('Password must be at least 6 characters', 'error');
    return false;
  }

  if (password !== confirmPassword) {
    showNotification('Passwords do not match', 'error');
    return false;
  }

  try {
    const existingUser = await getData('users', username);
    if (existingUser) {
      showNotification('Username already exists', 'error');
      return false;
    }

    const user = {
      username,
      email,
      password, // In production, this would be hashed
      createdAt: new Date().toISOString(),
      borrowedCount: 0,
      returnedCount: 0
    };

    await addData('users', user);
    showNotification('Registration successful! Please login.', 'success');
    return true;
  } catch (error) {
    showNotification('Registration failed', 'error');
    return false;
  }
}

async function login(username, password) {
  if (!username || !password) {
    showNotification('Username and password are required', 'error');
    return false;
  }

  try {
    const user = await getData('users', username);
    if (!user || user.password !== password) {
      showNotification('Invalid username or password', 'error');
      return false;
    }

    currentUser = user;
    showNotification(`Welcome back, ${user.username}!`, 'success');
    return true;
  } catch (error) {
    showNotification('Login failed', 'error');
    return false;
  }
}

function logout() {
  currentUser = null;
  userBorrowedBooks = [];
  navigateTo('login');
  showNotification('Logged out successfully', 'info');
}

// Book operations
async function loadUserBorrowedBooks() {
  if (!currentUser) return [];
  
  const borrowings = await getDataByIndex('borrowings', 'username', currentUser.username);
  const activeBorrowings = borrowings.filter(b => !b.returned);
  
  userBorrowedBooks = await Promise.all(
    activeBorrowings.map(async (borrowing) => {
      const book = await getData('books', borrowing.bookId);
      return { ...borrowing, book };
    })
  );
  
  return userBorrowedBooks;
}

async function borrowBook(bookId) {
  if (!currentUser) return;

  await loadUserBorrowedBooks();
  
  if (userBorrowedBooks.length >= MAX_BORROW_LIMIT) {
    showNotification(`You can only borrow up to ${MAX_BORROW_LIMIT} books at a time`, 'error');
    return;
  }

  const book = await getData('books', bookId);
  if (book.available <= 0) {
    showNotification('This book is currently unavailable', 'error');
    return;
  }

  // Check if user already borrowed this book
  const alreadyBorrowed = userBorrowedBooks.some(b => b.bookId === bookId);
  if (alreadyBorrowed) {
    showNotification('You have already borrowed this book', 'error');
    return;
  }

  // Update book availability
  book.available -= 1;
  await updateData('books', book);

  // Create borrowing record
  const borrowDate = new Date();
  const dueDate = new Date(borrowDate);
  dueDate.setDate(dueDate.getDate() + BORROW_DAYS);

  const borrowing = {
    username: currentUser.username,
    bookId: book.id,
    borrowDate: borrowDate.toISOString(),
    dueDate: dueDate.toISOString(),
    returned: false
  };

  await addData('borrowings', borrowing);

  // Update user stats
  currentUser.borrowedCount += 1;
  await updateData('users', currentUser);

  // Refresh data
  allBooks = await getAllData('books');
  await loadUserBorrowedBooks();

  showNotification(`Successfully borrowed "${book.title}"`, 'success');
  
  // Refresh current page
  if (currentPage === 'browse') {
    renderBrowsePage();
  } else if (currentPage === 'dashboard') {
    renderDashboard();
  }
  
  closeModal();
}

async function returnBook(borrowingId) {
  const borrowing = await getData('borrowings', borrowingId);
  if (!borrowing) return;

  const book = await getData('books', borrowing.bookId);
  
  // Update book availability
  book.available += 1;
  await updateData('books', book);

  // Mark as returned
  borrowing.returned = true;
  borrowing.returnDate = new Date().toISOString();
  await updateData('borrowings', borrowing);

  // Update user stats
  currentUser.returnedCount += 1;
  await updateData('users', currentUser);

  // Refresh data
  allBooks = await getAllData('books');
  await loadUserBorrowedBooks();

  showNotification(`Successfully returned "${book.title}"`, 'success');
  
  // Refresh current page
  if (currentPage === 'mybooks') {
    renderMyBooksPage();
  } else if (currentPage === 'dashboard') {
    renderDashboard();
  }
  
  closeModal();
}

function getDaysRemaining(dueDate) {
  const due = new Date(dueDate);
  const now = new Date();
  const diffTime = due - now;
  const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
  return diffDays;
}

function isOverdue(dueDate) {
  return getDaysRemaining(dueDate) < 0;
}

// Recommendation algorithm
async function getRecommendations() {
  if (!currentUser) return [];

  // Get user's borrowing history
  const allBorrowings = await getDataByIndex('borrowings', 'username', currentUser.username);
  const borrowedBookIds = allBorrowings.map(b => b.bookId);
  const borrowedBooks = await Promise.all(
    borrowedBookIds.map(id => getData('books', id))
  );

  // Get genres user has read
  const userGenres = [...new Set(borrowedBooks.map(b => b.genre))];

  // Get books user hasn't borrowed in those genres
  const recommendations = allBooks.filter(book => {
    const notBorrowed = !borrowedBookIds.includes(book.id);
    const sameGenre = userGenres.includes(book.genre);
    return notBorrowed && sameGenre && book.available > 0;
  });

  // Get popular books (most available copies)
  const popular = allBooks
    .filter(b => !borrowedBookIds.includes(b.id) && b.available > 0)
    .sort((a, b) => b.available - a.available)
    .slice(0, 6);

  // Get new arrivals (recent years)
  const newArrivals = allBooks
    .filter(b => !borrowedBookIds.includes(b.id) && b.year >= 2018 && b.available > 0)
    .sort((a, b) => b.year - a.year)
    .slice(0, 6);

  return {
    personalized: recommendations.slice(0, 6),
    popular,
    newArrivals
  };
}

// UI Helper functions
function showNotification(message, type = 'info') {
  const notification = document.getElementById('notification');
  const icon = notification.querySelector('.notification-icon');
  const messageEl = notification.querySelector('.notification-message');

  const icons = {
    success: '✓',
    error: '✕',
    info: 'ℹ'
  };

  icon.textContent = icons[type] || icons.info;
  messageEl.textContent = message;
  notification.className = `notification active ${type}`;

  setTimeout(() => {
    notification.classList.remove('active');
  }, 3000);
}

function showModal(title, body, actions = []) {
  const modal = document.getElementById('modal');
  const modalTitle = document.getElementById('modalTitle');
  const modalBody = document.getElementById('modalBody');
  const modalActions = document.getElementById('modalActions');

  modalTitle.textContent = title;
  modalBody.innerHTML = body;
  modalActions.innerHTML = actions.map(action => 
    `<button class="btn ${action.class}" onclick="${action.onClick}">${action.text}</button>`
  ).join('');

  modal.classList.add('active');
}

function closeModal() {
  const modal = document.getElementById('modal');
  modal.classList.remove('active');
}

// Page rendering functions
function navigateTo(page) {
  currentPage = page;
  
  if (page === 'login') {
    renderLoginPage();
  } else if (page === 'register') {
    renderRegisterPage();
  } else if (page === 'dashboard') {
    renderDashboard();
  } else if (page === 'browse') {
    renderBrowsePage();
  } else if (page === 'mybooks') {
    renderMyBooksPage();
  } else if (page === 'recommendations') {
    renderRecommendationsPage();
  } else if (page === 'profile') {
    renderProfilePage();
  }
}

function renderLoginPage() {
  const app = document.getElementById('app');
  app.innerHTML = `
    <div class="auth-container">
      <div class="auth-card">
        <div class="auth-header">
          <div class="logo">📚 Library System</div>
          <h1 class="auth-title">Welcome Back</h1>
          <p class="auth-subtitle">Sign in to your account</p>
        </div>
        <form id="loginForm" onsubmit="handleLogin(event)">
          <div class="form-group">
            <label class="form-label">Username</label>
            <input type="text" id="loginUsername" class="form-control" placeholder="Enter your username" required>
          </div>
          <div class="form-group">
            <label class="form-label">Password</label>
            <input type="password" id="loginPassword" class="form-control" placeholder="Enter your password" required>
          </div>
          <button type="submit" class="btn btn-primary">Sign In</button>
        </form>
        <div class="auth-switch">
          Don't have an account? <a onclick="navigateTo('register')">Register here</a>
        </div>
        <div class="auth-switch" style="margin-top: 12px; font-size: 11px; color: var(--color-text-secondary);">
          Demo: username: <strong>demo</strong> / password: <strong>demo123</strong> (register first)
        </div>
      </div>
    </div>
  `;
}

function renderRegisterPage() {
  const app = document.getElementById('app');
  app.innerHTML = `
    <div class="auth-container">
      <div class="auth-card">
        <div class="auth-header">
          <div class="logo">📚 Library System</div>
          <h1 class="auth-title">Create Account</h1>
          <p class="auth-subtitle">Join our library community</p>
        </div>
        <form id="registerForm" onsubmit="handleRegister(event)">
          <div class="form-group">
            <label class="form-label">Username</label>
            <input type="text" id="regUsername" class="form-control" placeholder="Choose a username" required>
          </div>
          <div class="form-group">
            <label class="form-label">Email</label>
            <input type="email" id="regEmail" class="form-control" placeholder="Enter your email" required>
          </div>
          <div class="form-group">
            <label class="form-label">Password</label>
            <input type="password" id="regPassword" class="form-control" placeholder="At least 6 characters" required>
          </div>
          <div class="form-group">
            <label class="form-label">Confirm Password</label>
            <input type="password" id="regConfirmPassword" class="form-control" placeholder="Re-enter password" required>
          </div>
          <button type="submit" class="btn btn-primary">Create Account</button>
        </form>
        <div class="auth-switch">
          Already have an account? <a onclick="navigateTo('login')">Sign in</a>
        </div>
      </div>
    </div>
  `;
}

function renderHeader() {
  return `
    <header class="header">
      <div class="header-content">
        <div class="logo">📚 Library System</div>
        <nav class="nav">
          <a class="nav-link ${currentPage === 'dashboard' ? 'active' : ''}" onclick="navigateTo('dashboard')">Dashboard</a>
          <a class="nav-link ${currentPage === 'browse' ? 'active' : ''}" onclick="navigateTo('browse')">Browse Books</a>
          <a class="nav-link ${currentPage === 'mybooks' ? 'active' : ''}" onclick="navigateTo('mybooks')">My Books</a>
          <a class="nav-link ${currentPage === 'recommendations' ? 'active' : ''}" onclick="navigateTo('recommendations')">Recommendations</a>
          <a class="nav-link ${currentPage === 'profile' ? 'active' : ''}" onclick="navigateTo('profile')">Profile</a>
          <a class="nav-link" onclick="logout()">Logout</a>
        </nav>
      </div>
    </header>
  `;
}

async function renderDashboard() {
  await loadUserBorrowedBooks();
  
  const app = document.getElementById('app');
  const createdDate = new Date(currentUser.createdAt).toLocaleDateString();
  
  app.innerHTML = `
    ${renderHeader()}
    <main class="main-content">
      <div class="dashboard-header">
        <h1 class="dashboard-title">Welcome, ${currentUser.username}! 👋</h1>
        <p class="dashboard-subtitle">Here's your library overview</p>
      </div>
      
      <div class="stats-grid">
        <div class="stat-card">
          <div class="stat-icon">📚</div>
          <div class="stat-value">${userBorrowedBooks.length}</div>
          <div class="stat-label">Currently Borrowed</div>
        </div>
        <div class="stat-card">
          <div class="stat-icon">✓</div>
          <div class="stat-value">${currentUser.returnedCount}</div>
          <div class="stat-label">Books Returned</div>
        </div>
        <div class="stat-card">
          <div class="stat-icon">📖</div>
          <div class="stat-value">${currentUser.borrowedCount}</div>
          <div class="stat-label">Total Borrowed</div>
        </div>
        <div class="stat-card">
          <div class="stat-icon">📅</div>
          <div class="stat-value">${createdDate}</div>
          <div class="stat-label">Member Since</div>
        </div>
      </div>

      ${userBorrowedBooks.length > 0 ? `
        <div class="section-title">Currently Reading</div>
        <div class="books-grid">
          ${userBorrowedBooks.slice(0, 4).map(borrowing => {
            const daysRemaining = getDaysRemaining(borrowing.dueDate);
            const overdue = isOverdue(borrowing.dueDate);
            return `
              <div class="book-card">
                <div class="book-cover">${borrowing.book.image}</div>
                <div class="book-title">${borrowing.book.title}</div>
                <div class="book-author">by ${borrowing.book.author}</div>
                <div class="book-meta">
                  <div style="color: ${overdue ? 'var(--color-error)' : 'var(--color-text-secondary)'}; font-weight: 500;">
                    ${overdue ? `Overdue by ${Math.abs(daysRemaining)} days` : `Due in ${daysRemaining} days`}
                  </div>
                </div>
              </div>
            `;
          }).join('')}
        </div>
      ` : `
        <div class="empty-state">
          <div class="empty-icon">📚</div>
          <div class="empty-title">No books borrowed yet</div>
          <div class="empty-text">Start exploring our collection!</div>
          <button class="btn btn-primary" onclick="navigateTo('browse')">Browse Books</button>
        </div>
      `}
    </main>
  `;
}

function renderBrowsePage() {
  const app = document.getElementById('app');
  
  app.innerHTML = `
    ${renderHeader()}
    <main class="main-content">
      <div class="dashboard-header">
        <h1 class="dashboard-title">Browse Books</h1>
        <p class="dashboard-subtitle">Discover your next great read</p>
      </div>

      <div class="search-filter-bar">
        <div class="search-box">
          <span class="search-icon">🔍</span>
          <input type="text" class="search-input" id="searchInput" placeholder="Search by title or author..." oninput="filterBooks()">
        </div>
        <select class="filter-select" id="genreFilter" onchange="filterBooks()">
          ${GENRES.map(genre => `<option value="${genre}">${genre}</option>`).join('')}
        </select>
      </div>

      <div id="booksContainer" class="books-grid"></div>
    </main>
  `;

  filterBooks();
}

function filterBooks() {
  const searchTerm = document.getElementById('searchInput').value.toLowerCase();
  const selectedGenre = document.getElementById('genreFilter').value;

  let filteredBooks = allBooks.filter(book => {
    const matchesSearch = book.title.toLowerCase().includes(searchTerm) || 
                         book.author.toLowerCase().includes(searchTerm);
    const matchesGenre = selectedGenre === 'All' || book.genre === selectedGenre;
    return matchesSearch && matchesGenre;
  });

  const container = document.getElementById('booksContainer');
  
  if (filteredBooks.length === 0) {
    container.innerHTML = `
      <div class="empty-state" style="grid-column: 1 / -1;">
        <div class="empty-icon">🔍</div>
        <div class="empty-title">No books found</div>
        <div class="empty-text">Try adjusting your search or filter</div>
      </div>
    `;
    return;
  }

  container.innerHTML = filteredBooks.map(book => `
    <div class="book-card" onclick="showBookDetails(${book.id})">
      <div class="book-cover">${book.image}</div>
      <div class="book-title">${book.title}</div>
      <div class="book-author">by ${book.author}</div>
      <div class="book-meta">
        <span class="book-genre">${book.genre}</span>
        <div class="book-available ${book.available > 0 ? '' : 'book-unavailable'}">
          ${book.available > 0 ? '✓' : '✕'} ${book.available} available
        </div>
      </div>
      <div class="book-actions">
        <button class="btn btn-primary btn-small" onclick="event.stopPropagation(); showBorrowConfirm(${book.id})" ${book.available <= 0 ? 'disabled' : ''}>
          Borrow Book
        </button>
      </div>
    </div>
  `).join('');
}

function showBookDetails(bookId) {
  const book = allBooks.find(b => b.id === bookId);
  if (!book) return;

  const body = `
    <div style="text-align: center; margin-bottom: 20px;">
      <div style="font-size: 64px; margin-bottom: 16px;">${book.image}</div>
      <h3 style="font-size: 20px; margin-bottom: 8px;">${book.title}</h3>
      <p style="color: var(--color-text-secondary); margin-bottom: 16px;">by ${book.author}</p>
    </div>
    <div class="profile-info">
      <div class="profile-info-item">
        <span class="profile-info-label">ISBN</span>
        <span class="profile-info-value">${book.isbn}</span>
      </div>
      <div class="profile-info-item">
        <span class="profile-info-label">Genre</span>
        <span class="profile-info-value">${book.genre}</span>
      </div>
      <div class="profile-info-item">
        <span class="profile-info-label">Publication Year</span>
        <span class="profile-info-value">${book.year}</span>
      </div>
      <div class="profile-info-item">
        <span class="profile-info-label">Available Copies</span>
        <span class="profile-info-value" style="color: ${book.available > 0 ? 'var(--color-success)' : 'var(--color-error)'}">
          ${book.available}
        </span>
      </div>
    </div>
  `;

  const actions = book.available > 0 ? [
    { text: 'Borrow Book', class: 'btn-primary', onClick: `showBorrowConfirm(${book.id})` },
    { text: 'Close', class: 'btn-secondary', onClick: 'closeModal()' }
  ] : [
    { text: 'Close', class: 'btn-secondary', onClick: 'closeModal()' }
  ];

  showModal(book.title, body, actions);
}

function showBorrowConfirm(bookId) {
  const book = allBooks.find(b => b.id === bookId);
  if (!book) return;

  const dueDate = new Date();
  dueDate.setDate(dueDate.getDate() + BORROW_DAYS);

  const body = `
    <p style="margin-bottom: 16px;">Are you sure you want to borrow <strong>"${book.title}"</strong>?</p>
    <div class="profile-info">
      <div class="profile-info-item">
        <span class="profile-info-label">Due Date</span>
        <span class="profile-info-value">${dueDate.toLocaleDateString()}</span>
      </div>
      <div class="profile-info-item">
        <span class="profile-info-label">Borrow Period</span>
        <span class="profile-info-value">${BORROW_DAYS} days</span>
      </div>
    </div>
  `;

  const actions = [
    { text: 'Confirm Borrow', class: 'btn-primary', onClick: `borrowBook(${bookId})` },
    { text: 'Cancel', class: 'btn-secondary', onClick: 'closeModal()' }
  ];

  showModal('Borrow Book', body, actions);
}

async function renderMyBooksPage() {
  await loadUserBorrowedBooks();
  
  const app = document.getElementById('app');
  
  app.innerHTML = `
    ${renderHeader()}
    <main class="main-content">
      <div class="dashboard-header">
        <h1 class="dashboard-title">My Books</h1>
        <p class="dashboard-subtitle">Books you've borrowed (${userBorrowedBooks.length}/${MAX_BORROW_LIMIT})</p>
      </div>

      ${userBorrowedBooks.length > 0 ? `
        <div class="table-container">
          <table class="table">
            <thead>
              <tr>
                <th>Book</th>
                <th>Author</th>
                <th>Borrowed Date</th>
                <th>Due Date</th>
                <th>Status</th>
                <th>Action</th>
              </tr>
            </thead>
            <tbody>
              ${userBorrowedBooks.map(borrowing => {
                const daysRemaining = getDaysRemaining(borrowing.dueDate);
                const overdue = isOverdue(borrowing.dueDate);
                const borrowDate = new Date(borrowing.borrowDate).toLocaleDateString();
                const dueDate = new Date(borrowing.dueDate).toLocaleDateString();
                
                return `
                  <tr class="${overdue ? 'overdue' : ''}">
                    <td>
                      <div style="display: flex; align-items: center; gap: 12px;">
                        <span style="font-size: 24px;">${borrowing.book.image}</span>
                        <strong>${borrowing.book.title}</strong>
                      </div>
                    </td>
                    <td>${borrowing.book.author}</td>
                    <td>${borrowDate}</td>
                    <td>${dueDate}</td>
                    <td>
                      <span style="font-weight: 500; color: ${overdue ? 'var(--color-error)' : 'var(--color-success)'}">
                        ${overdue ? `Overdue (${Math.abs(daysRemaining)} days)` : `${daysRemaining} days left`}
                      </span>
                    </td>
                    <td>
                      <button class="btn btn-secondary btn-small" onclick="showReturnConfirm(${borrowing.id})">
                        Return Book
                      </button>
                    </td>
                  </tr>
                `;
              }).join('')}
            </tbody>
          </table>
        </div>
      ` : `
        <div class="empty-state">
          <div class="empty-icon">📚</div>
          <div class="empty-title">No borrowed books</div>
          <div class="empty-text">Browse our collection to borrow your first book!</div>
          <button class="btn btn-primary" onclick="navigateTo('browse')">Browse Books</button>
        </div>
      `}
    </main>
  `;
}

function showReturnConfirm(borrowingId) {
  const borrowing = userBorrowedBooks.find(b => b.id === borrowingId);
  if (!borrowing) return;

  const body = `
    <p style="margin-bottom: 16px;">Are you sure you want to return <strong>"${borrowing.book.title}"</strong>?</p>
    <p style="color: var(--color-text-secondary); font-size: 14px;">This book will be available for other members to borrow.</p>
  `;

  const actions = [
    { text: 'Confirm Return', class: 'btn-primary', onClick: `returnBook(${borrowingId})` },
    { text: 'Cancel', class: 'btn-secondary', onClick: 'closeModal()' }
  ];

  showModal('Return Book', body, actions);
}

async function renderRecommendationsPage() {
  const recommendations = await getRecommendations();
  
  const app = document.getElementById('app');
  
  app.innerHTML = `
    ${renderHeader()}
    <main class="main-content">
      <div class="dashboard-header">
        <h1 class="dashboard-title">Recommendations</h1>
        <p class="dashboard-subtitle">Books we think you'll love</p>
      </div>

      ${recommendations.personalized.length > 0 ? `
        <div class="recommendations-section">
          <h2 class="section-title">Based on Your Reading History</h2>
          <div class="books-grid">
            ${recommendations.personalized.map(book => `
              <div class="book-card" onclick="showBookDetails(${book.id})">
                <div class="book-cover">${book.image}</div>
                <div class="book-title">${book.title}</div>
                <div class="book-author">by ${book.author}</div>
                <div class="book-meta">
                  <span class="book-genre">${book.genre}</span>
                </div>
                <div class="recommendation-badge">Similar to your interests</div>
                <div class="book-actions">
                  <button class="btn btn-primary btn-small" onclick="event.stopPropagation(); showBorrowConfirm(${book.id})">
                    Borrow Book
                  </button>
                </div>
              </div>
            `).join('')}
          </div>
        </div>
      ` : ''}

      <div class="recommendations-section">
        <h2 class="section-title">Popular This Month</h2>
        ${recommendations.popular.length > 0 ? `
          <div class="books-grid">
            ${recommendations.popular.map(book => `
              <div class="book-card" onclick="showBookDetails(${book.id})">
                <div class="book-cover">${book.image}</div>
                <div class="book-title">${book.title}</div>
                <div class="book-author">by ${book.author}</div>
                <div class="book-meta">
                  <span class="book-genre">${book.genre}</span>
                </div>
                <div class="book-actions">
                  <button class="btn btn-primary btn-small" onclick="event.stopPropagation(); showBorrowConfirm(${book.id})">
                    Borrow Book
                  </button>
                </div>
              </div>
            `).join('')}
          </div>
        ` : '<p style="color: var(--color-text-secondary);">No popular books available at the moment.</p>'}
      </div>

      <div class="recommendations-section">
        <h2 class="section-title">New Arrivals</h2>
        ${recommendations.newArrivals.length > 0 ? `
          <div class="books-grid">
            ${recommendations.newArrivals.map(book => `
              <div class="book-card" onclick="showBookDetails(${book.id})">
                <div class="book-cover">${book.image}</div>
                <div class="book-title">${book.title}</div>
                <div class="book-author">by ${book.author}</div>
                <div class="book-meta">
                  <span class="book-genre">${book.genre}</span>
                  <div style="font-size: 12px; color: var(--color-text-secondary);">Published ${book.year}</div>
                </div>
                <div class="book-actions">
                  <button class="btn btn-primary btn-small" onclick="event.stopPropagation(); showBorrowConfirm(${book.id})">
                    Borrow Book
                  </button>
                </div>
              </div>
            `).join('')}
          </div>
        ` : '<p style="color: var(--color-text-secondary);">No new arrivals available at the moment.</p>'}
      </div>
    </main>
  `;
}

async function renderProfilePage() {
  const allBorrowings = await getDataByIndex('borrowings', 'username', currentUser.username);
  const borrowHistory = await Promise.all(
    allBorrowings.slice(0, 10).map(async (borrowing) => {
      const book = await getData('books', borrowing.bookId);
      return { ...borrowing, book };
    })
  );

  const app = document.getElementById('app');
  const createdDate = new Date(currentUser.createdAt).toLocaleDateString();
  
  app.innerHTML = `
    ${renderHeader()}
    <main class="main-content">
      <div class="dashboard-header">
        <h1 class="dashboard-title">My Profile</h1>
        <p class="dashboard-subtitle">Manage your account and view your history</p>
      </div>

      <div class="profile-container">
        <div class="profile-card">
          <div class="profile-avatar">👤</div>
          <h2 class="profile-name">${currentUser.username}</h2>
          <p class="profile-email">${currentUser.email}</p>
          
          <div class="profile-info">
            <div class="profile-info-item">
              <span class="profile-info-label">Member Since</span>
              <span class="profile-info-value">${createdDate}</span>
            </div>
            <div class="profile-info-item">
              <span class="profile-info-label">Currently Borrowed</span>
              <span class="profile-info-value">${userBorrowedBooks.length}</span>
            </div>
            <div class="profile-info-item">
              <span class="profile-info-label">Total Borrowed</span>
              <span class="profile-info-value">${currentUser.borrowedCount}</span>
            </div>
            <div class="profile-info-item">
              <span class="profile-info-label">Books Returned</span>
              <span class="profile-info-value">${currentUser.returnedCount}</span>
            </div>
          </div>
        </div>

        <div>
          <div class="profile-card">
            <h3 class="section-title">Borrowing History</h3>
            ${borrowHistory.length > 0 ? `
              <div class="table-container">
                <table class="table">
                  <thead>
                    <tr>
                      <th>Book</th>
                      <th>Borrowed</th>
                      <th>Status</th>
                    </tr>
                  </thead>
                  <tbody>
                    ${borrowHistory.map(borrowing => {
                      const borrowDate = new Date(borrowing.borrowDate).toLocaleDateString();
                      const returned = borrowing.returned;
                      
                      return `
                        <tr>
                          <td>
                            <div style="display: flex; align-items: center; gap: 12px;">
                              <span style="font-size: 20px;">${borrowing.book.image}</span>
                              <div>
                                <strong>${borrowing.book.title}</strong>
                                <div style="font-size: 12px; color: var(--color-text-secondary);">
                                  by ${borrowing.book.author}
                                </div>
                              </div>
                            </div>
                          </td>
                          <td>${borrowDate}</td>
                          <td>
                            <span style="color: ${returned ? 'var(--color-success)' : 'var(--color-info)'}; font-weight: 500;">
                              ${returned ? '✓ Returned' : '📖 Reading'}
                            </span>
                          </td>
                        </tr>
                      `;
                    }).join('')}
                  </tbody>
                </table>
              </div>
            ` : `
              <div class="empty-state">
                <div class="empty-icon">📚</div>
                <div class="empty-title">No borrowing history</div>
                <div class="empty-text">Start borrowing books to see your history here</div>
              </div>
            `}
          </div>
        </div>
      </div>
    </main>
  `;
}

// Event handlers
async function handleLogin(event) {
  event.preventDefault();
  const username = document.getElementById('loginUsername').value;
  const password = document.getElementById('loginPassword').value;

  const success = await login(username, password);
  if (success) {
    navigateTo('dashboard');
  }
}

async function handleRegister(event) {
  event.preventDefault();
  const username = document.getElementById('regUsername').value;
  const email = document.getElementById('regEmail').value;
  const password = document.getElementById('regPassword').value;
  const confirmPassword = document.getElementById('regConfirmPassword').value;

  const success = await register(username, email, password, confirmPassword);
  if (success) {
    setTimeout(() => navigateTo('login'), 1500);
  }
}

// Initialize app
async function initApp() {
  try {
    await initDB();
    await initializeBooks();
    navigateTo('login');
  } catch (error) {
    console.error('Failed to initialize app:', error);
    showNotification('Failed to initialize application', 'error');
  }
}

// Close modal when clicking outside
window.onclick = function(event) {
  const modal = document.getElementById('modal');
  if (event.target === modal) {
    closeModal();
  }
};

// Start the application
initApp();